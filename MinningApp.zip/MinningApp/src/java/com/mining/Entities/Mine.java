/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.Entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ERavhengani
 */
@Entity
@Table(name = "mine")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mine.findAll", query = "SELECT m FROM Mine m"),
    @NamedQuery(name = "Mine.findByMineNumber", query = "SELECT m FROM Mine m WHERE m.mineNumber = :mineNumber"),
    @NamedQuery(name = "Mine.findByMineName", query = "SELECT m FROM Mine m WHERE m.mineName = :mineName")})
public class Mine implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "mine_number")
    private Integer mineNumber;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "mine_name")
    private String mineName;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mineNumber")
    private List<Manager> managerList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mineNumber")
    private List<Winder> winderList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mineNumber")
    private List<Lift> liftList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mineNumber")
    private List<Chairlift> chairliftList;
    @JoinColumn(name = "region_name", referencedColumnName = "region_name")
    @ManyToOne(optional = false)
    private Region regionName;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mineNumber")
    private List<Boiler> boilerList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mineNumber")
    private List<Shaft> shaftList;

    public Mine() {
    }

    public Mine(Integer mineNumber) {
        this.mineNumber = mineNumber;
    }

    public Mine(Integer mineNumber, String mineName) {
        this.mineNumber = mineNumber;
        this.mineName = mineName;
    }

    public Integer getMineNumber() {
        return mineNumber;
    }

    public void setMineNumber(Integer mineNumber) {
        this.mineNumber = mineNumber;
    }

    public String getMineName() {
        return mineName;
    }

    public void setMineName(String mineName) {
        this.mineName = mineName;
    }

    @XmlTransient
    public List<Manager> getManagerList() {
        return managerList;
    }

    public void setManagerList(List<Manager> managerList) {
        this.managerList = managerList;
    }

    @XmlTransient
    public List<Winder> getWinderList() {
        return winderList;
    }

    public void setWinderList(List<Winder> winderList) {
        this.winderList = winderList;
    }

    @XmlTransient
    public List<Lift> getLiftList() {
        return liftList;
    }

    public void setLiftList(List<Lift> liftList) {
        this.liftList = liftList;
    }

    @XmlTransient
    public List<Chairlift> getChairliftList() {
        return chairliftList;
    }

    public void setChairliftList(List<Chairlift> chairliftList) {
        this.chairliftList = chairliftList;
    }

    public Region getRegionName() {
        return regionName;
    }

    public void setRegionName(Region regionName) {
        this.regionName = regionName;
    }

    @XmlTransient
    public List<Boiler> getBoilerList() {
        return boilerList;
    }

    public void setBoilerList(List<Boiler> boilerList) {
        this.boilerList = boilerList;
    }

    @XmlTransient
    public List<Shaft> getShaftList() {
        return shaftList;
    }

    public void setShaftList(List<Shaft> shaftList) {
        this.shaftList = shaftList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (mineNumber != null ? mineNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mine)) {
            return false;
        }
        Mine other = (Mine) object;
        if ((this.mineNumber == null && other.mineNumber != null) || (this.mineNumber != null && !this.mineNumber.equals(other.mineNumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mining.Entities.Mine[ mineNumber=" + mineNumber + " ]";
    }
    
}
