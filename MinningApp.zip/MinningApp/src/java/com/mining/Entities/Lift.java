/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.Entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ERavhengani
 */
@Entity
@Table(name = "lift")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Lift.findAll", query = "SELECT l FROM Lift l"),
    @NamedQuery(name = "Lift.findByLiftNumber", query = "SELECT l FROM Lift l WHERE l.liftNumber = :liftNumber"),
    @NamedQuery(name = "Lift.findByMineName", query = "SELECT l FROM Lift l WHERE l.mineName = :mineName"),
    @NamedQuery(name = "Lift.findByNewLift", query = "SELECT l FROM Lift l WHERE l.newLift = :newLift"),
    @NamedQuery(name = "Lift.findByLiftStatus", query = "SELECT l FROM Lift l WHERE l.liftStatus = :liftStatus"),
    @NamedQuery(name = "Lift.findByIsLiftInstalledInAShaft", query = "SELECT l FROM Lift l WHERE l.isLiftInstalledInAShaft = :isLiftInstalledInAShaft"),
    @NamedQuery(name = "Lift.findByConveyanceType", query = "SELECT l FROM Lift l WHERE l.conveyanceType = :conveyanceType"),
    @NamedQuery(name = "Lift.findByConveyanceMass", query = "SELECT l FROM Lift l WHERE l.conveyanceMass = :conveyanceMass"),
    @NamedQuery(name = "Lift.findByLoadMass", query = "SELECT l FROM Lift l WHERE l.loadMass = :loadMass"),
    @NamedQuery(name = "Lift.findByLoadType", query = "SELECT l FROM Lift l WHERE l.loadType = :loadType"),
    @NamedQuery(name = "Lift.findByWindLength", query = "SELECT l FROM Lift l WHERE l.windLength = :windLength"),
    @NamedQuery(name = "Lift.findByMaxWindingSpeed", query = "SELECT l FROM Lift l WHERE l.maxWindingSpeed = :maxWindingSpeed"),
    @NamedQuery(name = "Lift.findByNumberOfLandings", query = "SELECT l FROM Lift l WHERE l.numberOfLandings = :numberOfLandings")})
public class Lift implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "lift_number")
    private Integer liftNumber;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "mine_name")
    private String mineName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "new_lift")
    private String newLift;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "lift_status")
    private String liftStatus;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "is_lift_installed_in_a_shaft")
    private String isLiftInstalledInAShaft;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "conveyance_type")
    private String conveyanceType;
    @Basic(optional = false)
    @NotNull
    @Column(name = "conveyance_mass")
    private float conveyanceMass;
    @Basic(optional = false)
    @NotNull
    @Column(name = "load_mass")
    private float loadMass;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "load_type")
    private String loadType;
    @Basic(optional = false)
    @NotNull
    @Column(name = "wind_length")
    private float windLength;
    @Basic(optional = false)
    @NotNull
    @Column(name = "max_winding_speed")
    private float maxWindingSpeed;
    @Basic(optional = false)
    @NotNull
    @Column(name = "number_of_landings")
    private int numberOfLandings;
    @JoinColumn(name = "shaft_number", referencedColumnName = "shaft_number")
    @ManyToOne(optional = false)
    private Shaft shaftNumber;
    @JoinColumn(name = "region_name", referencedColumnName = "region_name")
    @ManyToOne(optional = false)
    private Region regionName;
    @JoinColumn(name = "mine_number", referencedColumnName = "mine_number")
    @ManyToOne(optional = false)
    private Mine mineNumber;

    public Lift() {
    }

    public Lift(Integer liftNumber) {
        this.liftNumber = liftNumber;
    }

    public Lift(Integer liftNumber, String mineName, String newLift, String liftStatus, String isLiftInstalledInAShaft, String conveyanceType, float conveyanceMass, float loadMass, String loadType, float windLength, float maxWindingSpeed, int numberOfLandings) {
        this.liftNumber = liftNumber;
        this.mineName = mineName;
        this.newLift = newLift;
        this.liftStatus = liftStatus;
        this.isLiftInstalledInAShaft = isLiftInstalledInAShaft;
        this.conveyanceType = conveyanceType;
        this.conveyanceMass = conveyanceMass;
        this.loadMass = loadMass;
        this.loadType = loadType;
        this.windLength = windLength;
        this.maxWindingSpeed = maxWindingSpeed;
        this.numberOfLandings = numberOfLandings;
    }

    public Integer getLiftNumber() {
        return liftNumber;
    }

    public void setLiftNumber(Integer liftNumber) {
        this.liftNumber = liftNumber;
    }

    public String getMineName() {
        return mineName;
    }

    public void setMineName(String mineName) {
        this.mineName = mineName;
    }

    public String getNewLift() {
        return newLift;
    }

    public void setNewLift(String newLift) {
        this.newLift = newLift;
    }

    public String getLiftStatus() {
        return liftStatus;
    }

    public void setLiftStatus(String liftStatus) {
        this.liftStatus = liftStatus;
    }

    public String getIsLiftInstalledInAShaft() {
        return isLiftInstalledInAShaft;
    }

    public void setIsLiftInstalledInAShaft(String isLiftInstalledInAShaft) {
        this.isLiftInstalledInAShaft = isLiftInstalledInAShaft;
    }

    public String getConveyanceType() {
        return conveyanceType;
    }

    public void setConveyanceType(String conveyanceType) {
        this.conveyanceType = conveyanceType;
    }

    public float getConveyanceMass() {
        return conveyanceMass;
    }

    public void setConveyanceMass(float conveyanceMass) {
        this.conveyanceMass = conveyanceMass;
    }

    public float getLoadMass() {
        return loadMass;
    }

    public void setLoadMass(float loadMass) {
        this.loadMass = loadMass;
    }

    public String getLoadType() {
        return loadType;
    }

    public void setLoadType(String loadType) {
        this.loadType = loadType;
    }

    public float getWindLength() {
        return windLength;
    }

    public void setWindLength(float windLength) {
        this.windLength = windLength;
    }

    public float getMaxWindingSpeed() {
        return maxWindingSpeed;
    }

    public void setMaxWindingSpeed(float maxWindingSpeed) {
        this.maxWindingSpeed = maxWindingSpeed;
    }

    public int getNumberOfLandings() {
        return numberOfLandings;
    }

    public void setNumberOfLandings(int numberOfLandings) {
        this.numberOfLandings = numberOfLandings;
    }

    public Shaft getShaftNumber() {
        return shaftNumber;
    }

    public void setShaftNumber(Shaft shaftNumber) {
        this.shaftNumber = shaftNumber;
    }

    public Region getRegionName() {
        return regionName;
    }

    public void setRegionName(Region regionName) {
        this.regionName = regionName;
    }

    public Mine getMineNumber() {
        return mineNumber;
    }

    public void setMineNumber(Mine mineNumber) {
        this.mineNumber = mineNumber;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liftNumber != null ? liftNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Lift)) {
            return false;
        }
        Lift other = (Lift) object;
        if ((this.liftNumber == null && other.liftNumber != null) || (this.liftNumber != null && !this.liftNumber.equals(other.liftNumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mining.Entities.Lift[ liftNumber=" + liftNumber + " ]";
    }
    
}
