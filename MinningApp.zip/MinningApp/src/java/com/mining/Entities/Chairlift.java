/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.Entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ERavhengani
 */
@Entity
@Table(name = "chairlift")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Chairlift.findAll", query = "SELECT c FROM Chairlift c"),
    @NamedQuery(name = "Chairlift.findByChairliftNumber", query = "SELECT c FROM Chairlift c WHERE c.chairliftNumber = :chairliftNumber"),
    @NamedQuery(name = "Chairlift.findByMineName", query = "SELECT c FROM Chairlift c WHERE c.mineName = :mineName"),
    @NamedQuery(name = "Chairlift.findByNewChairlift", query = "SELECT c FROM Chairlift c WHERE c.newChairlift = :newChairlift"),
    @NamedQuery(name = "Chairlift.findByPreviousRegion", query = "SELECT c FROM Chairlift c WHERE c.previousRegion = :previousRegion"),
    @NamedQuery(name = "Chairlift.findByLocation", query = "SELECT c FROM Chairlift c WHERE c.location = :location"),
    @NamedQuery(name = "Chairlift.findByShaftName", query = "SELECT c FROM Chairlift c WHERE c.shaftName = :shaftName"),
    @NamedQuery(name = "Chairlift.findByManufacturer", query = "SELECT c FROM Chairlift c WHERE c.manufacturer = :manufacturer"),
    @NamedQuery(name = "Chairlift.findByYearManufactured", query = "SELECT c FROM Chairlift c WHERE c.yearManufactured = :yearManufactured"),
    @NamedQuery(name = "Chairlift.findByYearInstalled", query = "SELECT c FROM Chairlift c WHERE c.yearInstalled = :yearInstalled"),
    @NamedQuery(name = "Chairlift.findByDistanceBetweenDriveAndReturnSheave", query = "SELECT c FROM Chairlift c WHERE c.distanceBetweenDriveAndReturnSheave = :distanceBetweenDriveAndReturnSheave"),
    @NamedQuery(name = "Chairlift.findByMaxNoOfChair", query = "SELECT c FROM Chairlift c WHERE c.maxNoOfChair = :maxNoOfChair"),
    @NamedQuery(name = "Chairlift.findByDistanceBetweenChairs", query = "SELECT c FROM Chairlift c WHERE c.distanceBetweenChairs = :distanceBetweenChairs"),
    @NamedQuery(name = "Chairlift.findByChairSpeed", query = "SELECT c FROM Chairlift c WHERE c.chairSpeed = :chairSpeed"),
    @NamedQuery(name = "Chairlift.findByCapacity", query = "SELECT c FROM Chairlift c WHERE c.capacity = :capacity"),
    @NamedQuery(name = "Chairlift.findByMaxInclinationAngle", query = "SELECT c FROM Chairlift c WHERE c.maxInclinationAngle = :maxInclinationAngle"),
    @NamedQuery(name = "Chairlift.findByChairConnection", query = "SELECT c FROM Chairlift c WHERE c.chairConnection = :chairConnection"),
    @NamedQuery(name = "Chairlift.findByChairType", query = "SELECT c FROM Chairlift c WHERE c.chairType = :chairType"),
    @NamedQuery(name = "Chairlift.findByPowerOfDrivingMotor", query = "SELECT c FROM Chairlift c WHERE c.powerOfDrivingMotor = :powerOfDrivingMotor"),
    @NamedQuery(name = "Chairlift.findByMainBreakType", query = "SELECT c FROM Chairlift c WHERE c.mainBreakType = :mainBreakType"),
    @NamedQuery(name = "Chairlift.findByBackupBreakType", query = "SELECT c FROM Chairlift c WHERE c.backupBreakType = :backupBreakType"),
    @NamedQuery(name = "Chairlift.findByInstallationType", query = "SELECT c FROM Chairlift c WHERE c.installationType = :installationType"),
    @NamedQuery(name = "Chairlift.findByHaulingChainRopeParticulars", query = "SELECT c FROM Chairlift c WHERE c.haulingChainRopeParticulars = :haulingChainRopeParticulars"),
    @NamedQuery(name = "Chairlift.findByDrawings", query = "SELECT c FROM Chairlift c WHERE c.drawings = :drawings"),
    @NamedQuery(name = "Chairlift.findByManufacturerSpecification", query = "SELECT c FROM Chairlift c WHERE c.manufacturerSpecification = :manufacturerSpecification"),
    @NamedQuery(name = "Chairlift.findByRopeAndChainsParticulars", query = "SELECT c FROM Chairlift c WHERE c.ropeAndChainsParticulars = :ropeAndChainsParticulars"),
    @NamedQuery(name = "Chairlift.findByRopeTensioningDevice", query = "SELECT c FROM Chairlift c WHERE c.ropeTensioningDevice = :ropeTensioningDevice"),
    @NamedQuery(name = "Chairlift.findBySpecialCarries", query = "SELECT c FROM Chairlift c WHERE c.specialCarries = :specialCarries")})
public class Chairlift implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "chairlift_number")
    private Integer chairliftNumber;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "mine_name")
    private String mineName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "new_chairlift")
    private String newChairlift;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "previous_region")
    private String previousRegion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "location")
    private String location;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "shaft_name")
    private String shaftName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "manufacturer")
    private String manufacturer;
    @Basic(optional = false)
    @NotNull
    @Column(name = "year_manufactured")
    private int yearManufactured;
    @Basic(optional = false)
    @NotNull
    @Column(name = "year_installed")
    private int yearInstalled;
    @Basic(optional = false)
    @NotNull
    @Column(name = "distance_between_drive_and_return_sheave")
    private float distanceBetweenDriveAndReturnSheave;
    @Basic(optional = false)
    @NotNull
    @Column(name = "max_no_of_chair")
    private float maxNoOfChair;
    @Basic(optional = false)
    @NotNull
    @Column(name = "distance_between_chairs")
    private float distanceBetweenChairs;
    @Basic(optional = false)
    @NotNull
    @Column(name = "chair_speed")
    private float chairSpeed;
    @Basic(optional = false)
    @NotNull
    @Column(name = "capacity")
    private int capacity;
    @Basic(optional = false)
    @NotNull
    @Column(name = "max_inclination_angle")
    private float maxInclinationAngle;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "chair_connection")
    private String chairConnection;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "chair_type")
    private String chairType;
    @Basic(optional = false)
    @NotNull
    @Column(name = "power_of_driving_motor")
    private float powerOfDrivingMotor;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "main_break_type")
    private String mainBreakType;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "backup_break_type")
    private String backupBreakType;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "installation_type")
    private String installationType;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "hauling_chain_rope_particulars")
    private String haulingChainRopeParticulars;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "drawings")
    private String drawings;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "manufacturer_specification")
    private String manufacturerSpecification;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "rope_and_chains_particulars")
    private String ropeAndChainsParticulars;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "rope_tensioning_device")
    private String ropeTensioningDevice;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "special_carries")
    private String specialCarries;
    @JoinColumn(name = "shaft_number", referencedColumnName = "shaft_number")
    @ManyToOne(optional = false)
    private Shaft shaftNumber;
    @JoinColumn(name = "region_name", referencedColumnName = "region_name")
    @ManyToOne(optional = false)
    private Region regionName;
    @JoinColumn(name = "mine_number", referencedColumnName = "mine_number")
    @ManyToOne(optional = false)
    private Mine mineNumber;

    public Chairlift() {
    }

    public Chairlift(Integer chairliftNumber) {
        this.chairliftNumber = chairliftNumber;
    }

    public Chairlift(Integer chairliftNumber, String mineName, String newChairlift, String previousRegion, String location, String shaftName, String manufacturer, int yearManufactured, int yearInstalled, float distanceBetweenDriveAndReturnSheave, float maxNoOfChair, float distanceBetweenChairs, float chairSpeed, int capacity, float maxInclinationAngle, String chairConnection, String chairType, float powerOfDrivingMotor, String mainBreakType, String backupBreakType, String installationType, String haulingChainRopeParticulars, String drawings, String manufacturerSpecification, String ropeAndChainsParticulars, String ropeTensioningDevice, String specialCarries) {
        this.chairliftNumber = chairliftNumber;
        this.mineName = mineName;
        this.newChairlift = newChairlift;
        this.previousRegion = previousRegion;
        this.location = location;
        this.shaftName = shaftName;
        this.manufacturer = manufacturer;
        this.yearManufactured = yearManufactured;
        this.yearInstalled = yearInstalled;
        this.distanceBetweenDriveAndReturnSheave = distanceBetweenDriveAndReturnSheave;
        this.maxNoOfChair = maxNoOfChair;
        this.distanceBetweenChairs = distanceBetweenChairs;
        this.chairSpeed = chairSpeed;
        this.capacity = capacity;
        this.maxInclinationAngle = maxInclinationAngle;
        this.chairConnection = chairConnection;
        this.chairType = chairType;
        this.powerOfDrivingMotor = powerOfDrivingMotor;
        this.mainBreakType = mainBreakType;
        this.backupBreakType = backupBreakType;
        this.installationType = installationType;
        this.haulingChainRopeParticulars = haulingChainRopeParticulars;
        this.drawings = drawings;
        this.manufacturerSpecification = manufacturerSpecification;
        this.ropeAndChainsParticulars = ropeAndChainsParticulars;
        this.ropeTensioningDevice = ropeTensioningDevice;
        this.specialCarries = specialCarries;
    }

    public Integer getChairliftNumber() {
        return chairliftNumber;
    }

    public void setChairliftNumber(Integer chairliftNumber) {
        this.chairliftNumber = chairliftNumber;
    }

    public String getMineName() {
        return mineName;
    }

    public void setMineName(String mineName) {
        this.mineName = mineName;
    }

    public String getNewChairlift() {
        return newChairlift;
    }

    public void setNewChairlift(String newChairlift) {
        this.newChairlift = newChairlift;
    }

    public String getPreviousRegion() {
        return previousRegion;
    }

    public void setPreviousRegion(String previousRegion) {
        this.previousRegion = previousRegion;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getShaftName() {
        return shaftName;
    }

    public void setShaftName(String shaftName) {
        this.shaftName = shaftName;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public int getYearManufactured() {
        return yearManufactured;
    }

    public void setYearManufactured(int yearManufactured) {
        this.yearManufactured = yearManufactured;
    }

    public int getYearInstalled() {
        return yearInstalled;
    }

    public void setYearInstalled(int yearInstalled) {
        this.yearInstalled = yearInstalled;
    }

    public float getDistanceBetweenDriveAndReturnSheave() {
        return distanceBetweenDriveAndReturnSheave;
    }

    public void setDistanceBetweenDriveAndReturnSheave(float distanceBetweenDriveAndReturnSheave) {
        this.distanceBetweenDriveAndReturnSheave = distanceBetweenDriveAndReturnSheave;
    }

    public float getMaxNoOfChair() {
        return maxNoOfChair;
    }

    public void setMaxNoOfChair(float maxNoOfChair) {
        this.maxNoOfChair = maxNoOfChair;
    }

    public float getDistanceBetweenChairs() {
        return distanceBetweenChairs;
    }

    public void setDistanceBetweenChairs(float distanceBetweenChairs) {
        this.distanceBetweenChairs = distanceBetweenChairs;
    }

    public float getChairSpeed() {
        return chairSpeed;
    }

    public void setChairSpeed(float chairSpeed) {
        this.chairSpeed = chairSpeed;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public float getMaxInclinationAngle() {
        return maxInclinationAngle;
    }

    public void setMaxInclinationAngle(float maxInclinationAngle) {
        this.maxInclinationAngle = maxInclinationAngle;
    }

    public String getChairConnection() {
        return chairConnection;
    }

    public void setChairConnection(String chairConnection) {
        this.chairConnection = chairConnection;
    }

    public String getChairType() {
        return chairType;
    }

    public void setChairType(String chairType) {
        this.chairType = chairType;
    }

    public float getPowerOfDrivingMotor() {
        return powerOfDrivingMotor;
    }

    public void setPowerOfDrivingMotor(float powerOfDrivingMotor) {
        this.powerOfDrivingMotor = powerOfDrivingMotor;
    }

    public String getMainBreakType() {
        return mainBreakType;
    }

    public void setMainBreakType(String mainBreakType) {
        this.mainBreakType = mainBreakType;
    }

    public String getBackupBreakType() {
        return backupBreakType;
    }

    public void setBackupBreakType(String backupBreakType) {
        this.backupBreakType = backupBreakType;
    }

    public String getInstallationType() {
        return installationType;
    }

    public void setInstallationType(String installationType) {
        this.installationType = installationType;
    }

    public String getHaulingChainRopeParticulars() {
        return haulingChainRopeParticulars;
    }

    public void setHaulingChainRopeParticulars(String haulingChainRopeParticulars) {
        this.haulingChainRopeParticulars = haulingChainRopeParticulars;
    }

    public String getDrawings() {
        return drawings;
    }

    public void setDrawings(String drawings) {
        this.drawings = drawings;
    }

    public String getManufacturerSpecification() {
        return manufacturerSpecification;
    }

    public void setManufacturerSpecification(String manufacturerSpecification) {
        this.manufacturerSpecification = manufacturerSpecification;
    }

    public String getRopeAndChainsParticulars() {
        return ropeAndChainsParticulars;
    }

    public void setRopeAndChainsParticulars(String ropeAndChainsParticulars) {
        this.ropeAndChainsParticulars = ropeAndChainsParticulars;
    }

    public String getRopeTensioningDevice() {
        return ropeTensioningDevice;
    }

    public void setRopeTensioningDevice(String ropeTensioningDevice) {
        this.ropeTensioningDevice = ropeTensioningDevice;
    }

    public String getSpecialCarries() {
        return specialCarries;
    }

    public void setSpecialCarries(String specialCarries) {
        this.specialCarries = specialCarries;
    }

    public Shaft getShaftNumber() {
        return shaftNumber;
    }

    public void setShaftNumber(Shaft shaftNumber) {
        this.shaftNumber = shaftNumber;
    }

    public Region getRegionName() {
        return regionName;
    }

    public void setRegionName(Region regionName) {
        this.regionName = regionName;
    }

    public Mine getMineNumber() {
        return mineNumber;
    }

    public void setMineNumber(Mine mineNumber) {
        this.mineNumber = mineNumber;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (chairliftNumber != null ? chairliftNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Chairlift)) {
            return false;
        }
        Chairlift other = (Chairlift) object;
        if ((this.chairliftNumber == null && other.chairliftNumber != null) || (this.chairliftNumber != null && !this.chairliftNumber.equals(other.chairliftNumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mining.Entities.Chairlift[ chairliftNumber=" + chairliftNumber + " ]";
    }
    
}
