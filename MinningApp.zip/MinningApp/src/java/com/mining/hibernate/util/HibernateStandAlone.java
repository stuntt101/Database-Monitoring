package com.mining.hibernate.util;

import java.util.List;

import org.hibernate.Session;


import com.mining.Entities.*;
import org.hibernate.Query;
import org.hibernate.Transaction;


public class HibernateStandAlone {
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
	    
	    Region region = new Region("North AFrica");
	   
	    Mine mine2    =new Mine(1441,"Mine2");
	    
	    Manager manager = new Manager ("Angel", "232323", "Angel", "Zungu","AZungu@csir.co.za");
	  
	    
//            Inspector ins1 = new Inspector ("Lungelo", "121212", "Lungelo", "Qwabe","LQwabe@csir.co.za");
//            Inspector ins2 = new Inspector ("Joshua", "121212", "Joshua", "Brill","BJoshuae@csir.co.za");
//	    
        
	     
    
            Region region3 = HibernateStandAlone. getRegionByName("South Africa");
	    manager.setRegionName(region3);
	    manager.setMineNumber(mine2);
	    manager.setMineName(mine2.getMineName());
		


		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();

        	//session.persist(region);

////		

	        //session.persist(manager);


//              List<Admin> admins = (List<Admin>)session.createQuery("from Admin").list();
//               for(Admin ins: admins){
//		System.out.println("Admin Details : "+ins);
//			
//		}
		
		
		List<Manager> managers = (List<Manager>)session.createQuery("from Manager ").list();
		for(Manager ins:  managers){
		System.out.println("Manager Details : "+ins);
			System.out.println("Manager Region : "+ins.getRegionName());
		}
		
		session.getTransaction().commit();
		session.close();  
	}

	public static Region getRegionByName(String regionName) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        Region region = null;
        try {
            tx = session.getTransaction();
            tx.begin();
            Query query = session.createQuery("from Region where regionName='"+regionName+"'");
            region = (Region)query.uniqueResult();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return region;
    }
	
}
