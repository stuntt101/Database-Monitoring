/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Chairlift;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ERavhengani
 */
@Local
public interface ChairliftControlLocal {

    void addChairlift(Chairlift chairlift);

    void updateChairlift(Chairlift chairlift);

    void deleteChairlift(Integer id);

  

    public Chairlift getChairliftById(Integer in);

    public List getChairliftByNumber(Integer Id);

    public List getChairliftByMine(String minename);



    public List getChairlifts();

    public List getChairliftByDrawings(String drawings);

    





    
}
