/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Boiler;
import java.util.List;
import javax.annotation.PreDestroy;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author ERavhengani
 */
@Stateless
public class BoilerControl implements BoilerControlLocal {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @PersistenceContext
    private EntityManager em;

    @Override
    public void addBoiler(Boiler boiler) {
        em.persist(boiler);
    }

    @Override
    public void updateBoiler(Boiler boiler) {
        em.merge(boiler);

    }

    @Override
    public void deleteBoiler(Integer id) {
        em.remove(em.find(Boiler.class, id));
    }

    @Override
    public List getBoilers() {
        Query query = em.createNamedQuery("Boiler.findAll").setMaxResults(100);
        return query.getResultList();
    }

    @Override
    public Boiler getBoilerById(Integer in) {
        return em.find(Boiler.class, in);
    }

    @Override
    public List getBoilerByNumber(Integer Id) {
        Query query = em.createNamedQuery("Boiler.findByBoilerNumber").setMaxResults(100);
        query.setParameter("boilerNumber", Id);
        return query.getResultList();
    }

    @Override
    public List getBoilerByStatus(String status) {//
        Query query = em.createNamedQuery("Boiler.findByBoilerStatus").setMaxResults(100);
        query.setParameter("boilerStatus", status);
        return query.getResultList();
    }

    @Override
    public List getBoilerByMine(String minename) {
        Query query = em.createNamedQuery("Boiler.findByMineName").setMaxResults(100);
        query.setParameter("mineName", minename);
        return query.getResultList();
    }




}
