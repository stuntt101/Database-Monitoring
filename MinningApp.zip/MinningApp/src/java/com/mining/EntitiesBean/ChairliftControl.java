/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Chairlift;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author ERavhengani
 */
@Stateless
public class ChairliftControl implements ChairliftControlLocal {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
    @PersistenceContext
    private EntityManager em;

    @Override
    public void addChairlift(Chairlift chairlift) {
        em.persist(chairlift);
        
    }

    @Override
    public void updateChairlift(Chairlift chairlift) {
        em.merge(chairlift);
    }

    @Override
    public void deleteChairlift(Integer id) {
        em.remove(em.find(Chairlift.class, id));
        
    }
    
    @Override
    public List getChairlifts(){
    Query query = em.createNamedQuery("Chairlift.findAll").setMaxResults(100);
    return query.getResultList();

}
    
    
    
    @Override
    public Chairlift getChairliftById(Integer in){
    return em.find(Chairlift.class, in);
    
    }
    
    @Override
    public List getChairliftByNumber (Integer Id){
        Query query = em.createNamedQuery("Chairlift.findByChairliftNumber").setMaxResults(100);
        query.setParameter("chairliftNumber", Id);
        return query.getResultList();
        
    }
    
        @Override
    public List getChairliftByMine (String minename){
        Query query = em.createNamedQuery("Chairlift.findByMineName").setMaxResults(100);
        query.setParameter("mineName", minename);
        return query.getResultList();
        
    }
    
        @Override
    public List getChairliftByDrawings (String drawings){
        Query query = em.createNamedQuery("Chairlift.findByDrawings").setMaxResults(100);
        query.setParameter("drawings", drawings);
        return query.getResultList();
        
    }


    
    
    
}
