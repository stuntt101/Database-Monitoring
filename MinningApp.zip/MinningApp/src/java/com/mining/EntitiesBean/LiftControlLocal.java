/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Lift;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ERavhengani
 */
@Local
public interface LiftControlLocal {

    void addLift(Lift lift);


    void updateLift(Lift lift);


    public void deleteLift(Integer id);

    public List getLifts();

    public Lift getLiftById(Integer in);

    public List getLiftByNumber(Integer Id);

    public List getLiftByMine(String minename);

    public List getLiftByStatus(String status);


    
}
