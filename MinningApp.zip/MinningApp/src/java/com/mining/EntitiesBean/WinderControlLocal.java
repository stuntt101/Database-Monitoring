/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Winder;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ERavhengani
 */
@Local
public interface WinderControlLocal {

    void addWinder(Winder winder);

    void updateWinder(Winder winder);

    void deleteWinder(Integer id);

    public List getWinders();



    public Winder getWinderById(Integer in);

 List getWinderByNumber(Integer Id);

 List getWinderByMine(String minename);

 List getWinderByShaft(String name);

 List getWinderByStatus(String status);

  List getWinderByClass(String classy);
    
}
