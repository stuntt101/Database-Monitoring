/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.service;

import com.mining.hibernate.util.HibernateUtil;
import com.mining.Entities.*;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author LQwabe
 */
public class ManagerService {

    /**
     *
     * @param manager
     * @return
     */
    public boolean addManager(Manager manager) {
	Session session = HibernateUtil.getSessionFactory().openSession();
	if (isManagerExists(manager)) {
	    return false;
	}

	Transaction tx = null;
	try {
	    tx = session.getTransaction();
	    tx.begin();
	    session.saveOrUpdate(manager);
	    tx.commit();
	} catch (Exception e) {
	    if (tx != null) {
		tx.rollback();
	    }
	    e.printStackTrace();
	} finally {
	    session.close();
	}
	return true;
    }

    /**
     *
     * @param username
     */
    public void deleteManager(String username) {
	Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            Manager manager = (Manager) session.load(Manager.class, new String(username));
            session.delete(manager);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }

    }
    
    /**
     *
     * @param manager
     */
    public void updateManager(Manager manager) {
	Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            session.update(manager);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }

    }

    /**
     *
     * @return
     */
    public List<Manager> getAllManagers() {
	List<Manager> list = new ArrayList<Manager>();
	Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	try {
	    tx = session.getTransaction();
	    tx.begin();
	    list = session.createQuery("from Manager").list();
	    tx.commit();
	} catch (Exception e) {
	    if (tx != null) {
		tx.rollback();
	    }
	    e.printStackTrace();
	} finally {
	    session.close();
	}
	return list;
    }

    /**
     *
     * @param username
     * @return
     */
    public List<Manager> getManagers(String username) {
	List<Manager> list = new ArrayList<Manager>();
	     Manager manager = null;
	Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	try {
	    tx = session.getTransaction();
	    tx.begin();
	    list = session.createQuery("from Manager where username='" + manager.getUsername() + "'").list();
	    tx.commit();
	} catch (Exception e) {
	    if (tx != null) {
		tx.rollback();
	    }
	    e.printStackTrace();
	} finally {
	    session.close();
	}
	return list;
    }

    /**
     *
     * @param manager
     * @return
     */
    public boolean isManagerExists(Manager manager) {
	Session session = HibernateUtil.getSessionFactory().openSession();
	boolean result = false;
	Transaction tx = null;
	try {
	    tx = session.getTransaction();
	    tx.begin();
	    Query query = session.createQuery("from Manager where username='" + manager.getUsername() + "'");
	    Manager mng = (Manager) query.uniqueResult();
	    tx.commit();
	    if (mng != null) {
		result = true;
	    }
	} catch (Exception ex) {
	    if (tx != null) {
		tx.rollback();
	    }
	} finally {
	    session.close();
	}
	return result;
    }
    
    /**
     *
     * @param username
     * @return
     */
    public Manager getManagerByUsername(String username) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
       Manager manager = null;
        try {
            tx = session.getTransaction();
            tx.begin();
            Query query = session.createQuery("from Manager where username='"+username+"'");
            manager = (Manager)query.uniqueResult();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return  manager;
    }
    
    
     /**
     *
     * @param  firstname
     * @return
     */
   
    
     public List<Manager> getManagerByFirstname(String firstname) {
	
	List<Manager> list = new ArrayList<Manager>();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
       Manager manager = null;
        try {
	    
	    tx = session.getTransaction();
	    tx.begin();
	    list = session.createQuery("from Manager where firstname='" + firstname + "'").list();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return  list;
    }
     
     public List<Manager> getManagerByLastname(String lastname) {
	
	List<Manager> list = new ArrayList<Manager>();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
       Manager manager = null;
        try {
	    
	    tx = session.getTransaction();
	    tx.begin();
	    list = session.createQuery("from Manager where lastname='" + lastname + "'").list();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return  list;
    }
    
    
    /**
     *
     * @param region
     * @return
     */
    public List<Manager> getManagersByRegion(Region region) {
	
	List<Manager> list = new ArrayList<Manager>();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
       Manager manager = null;
        try {
	    
	    tx = session.getTransaction();
	    tx.begin();
	    list = session.createQuery("from Manager where regionName='" + region.getRegionName() + "'").list();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return  list;
    }
    

}
