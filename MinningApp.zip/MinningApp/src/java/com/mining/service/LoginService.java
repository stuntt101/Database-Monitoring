package com.mining.service;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.mining.Entities.*;
import com.mining.hibernate.util.HibernateUtil;

/**
 *
 * @author LQwabe
 */
public class LoginService {

    /**
     *
     * @param username
     * @param password
     * @return
     */
    public boolean authenticateAdmin(String username, String password) {
        Admin admin = getAdminByUsername(username);          
        if(admin!=null && admin.getUsername().equals(username) && admin.getPassword().equals(password)){
            return true;
        }else{ 
            return false;
        }
    }
    
    /**
     *
     * @param username
     * @param password
     * @return
     */
    public boolean authenticateManager(String username, String password) {
       ManagerService service = new 	ManagerService();
       Manager manager= service.getManagerByUsername(username);          
        if(manager!=null && manager.getUsername().equals(username) && manager.getPassword().equals(password)){
            return true;
        }else{ 
            return false;
        }
    }
    
    /**
     *
     * @param username
     * @param password
     * @return
     */
    public boolean authenticateInspector(String username, String password) {
       InspectorService service = new 	InspectorService();
      Inspector inspector= service.getInspectorByUsername(username);          
        if(inspector!=null && inspector.getUsername().equals(username) && inspector.getPassword().equals(password)){
            return true;
        }else{ 
            return false;
        }
    }
    
    /**
     *
     * @param username
     * @return
     */
    public Admin getAdminByUsername(String username) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        Admin admin = null;
        try {
            tx = session.getTransaction();
            tx.begin();
            Query query = session.createQuery("from Admin where username='"+username+"'");
            admin = (Admin)query.uniqueResult();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return admin;
    }
    
    /**
     *
     * @return
     */
    public List<Admin> getListOfAdmins(){
        List<Admin> list = new ArrayList<Admin>();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;        
        try {
            tx = session.getTransaction();
            tx.begin();
            list = session.createQuery("from Admin").list();                        
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return list;
    }
}
