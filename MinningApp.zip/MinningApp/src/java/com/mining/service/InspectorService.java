/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.service;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mining.hibernate.util.HibernateUtil;
import com.mining.Entities.*;
import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author LQwabe
 */
public class InspectorService {

    /**
     *
     * @param inspector
     * @return true
     */
    public boolean addInspector(Inspector inspector) {
	Session session = HibernateUtil.getSessionFactory().openSession();
	if (isInspectorExists(inspector)) {
	    return false;
	}

	Transaction tx = null;
	try {
	    tx = session.getTransaction();
	    tx.begin();
	    session.save(inspector);
	    tx.commit();
	} catch (Exception e) {
	    if (tx != null) {
		tx.rollback();
	    }
	    e.printStackTrace();
	} finally {
	    session.close();
	}
	return true;
    }

    /**
     *
     * @param username
     */
    public void deleteInspector(String username) {
	Transaction trns = null;
	Session session = HibernateUtil.getSessionFactory().openSession();
	try {
	    trns = session.beginTransaction();
	    Inspector inspector = (Inspector) session.load(Inspector.class, new String(username));
	    session.delete(inspector);
	    session.getTransaction().commit();
	} catch (RuntimeException e) {
	    if (trns != null) {
		trns.rollback();
	    }
	    e.printStackTrace();
	} finally {
	    session.flush();
	    session.close();
	}

    }

    /**
     *
     * @param inspector
     */
    public void updateInspector(Inspector inspector) {
	Transaction trns = null;
	Session session = HibernateUtil.getSessionFactory().openSession();
	try {
	    trns = session.beginTransaction();
	    session.update(inspector);
	    session.getTransaction().commit();
	} catch (RuntimeException e) {
	    if (trns != null) {
		trns.rollback();
	    }
	    e.printStackTrace();
	} finally {
	    session.flush();
	    session.close();
	}

    }

    /**
     *
     * @return a list of inspectors
     */
    public List<Inspector> getAllInspectors() {
	List<Inspector> list = new ArrayList<Inspector>();
	Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	try {
	    tx = session.getTransaction();
	    tx.begin();
	    list = session.createQuery("from Inspector").list();
	    tx.commit();
	} catch (Exception e) {
	    if (tx != null) {
		tx.rollback();
	    }
	    e.printStackTrace();
	} finally {
	    session.close();
	}
	return list;
    }

    /**
     *
     * @param inspector
     * @return
     */
    public boolean isInspectorExists(Inspector inspector) {
	Session session = HibernateUtil.getSessionFactory().openSession();
	boolean result = false;
	Transaction tx = null;
	try {
	    tx = session.getTransaction();
	    tx.begin();
	    Query query = session.createQuery("from Inspector where username='" + inspector.getUsername() + "'");
	    Inspector ins = (Inspector) query.uniqueResult();
	    tx.commit();
	    if (ins != null) {
		result = true;
	    }
	} catch (Exception ex) {
	    if (tx != null) {
		tx.rollback();
	    }
	} finally {
	    session.close();
	}
	return result;
    }

    /**
     *
     * @param username
     * @return
     */
    public Inspector getInspectorByUsername(String username) {
	Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	Inspector inspector = null;
	try {
	    tx = session.getTransaction();
	    tx.begin();
	    Query query = session.createQuery("from Inspector where username='" + username + "'");
	    inspector = (Inspector) query.uniqueResult();
	    tx.commit();
	} catch (Exception e) {
	    if (tx != null) {
		tx.rollback();
	    }
	    e.printStackTrace();
	} finally {
	    session.close();
	}
	return inspector;
    }
    
    /**
     *
     * @param region
     * @return
     */
    public Inspector getInspectorByRegion(Region region) {
	
	List<Manager> list = new ArrayList<Manager>();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
      Inspector  inspector = null;
        try {
	    
	    tx = session.getTransaction();
	    tx.begin();
	    Query query = session.createQuery("from Manager where regionName='" + region.getRegionName() + "'");
	    inspector = (Inspector) query.uniqueResult();
	    tx.commit();
	    
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return  inspector;
    }
    
     /**
     *
     * @param  firstname
     * @return
     */
   
    
     public List<Inspector> getInspectorByFirstname(String firstname) {
	
	List<Inspector> list = new ArrayList<Inspector>();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
       Inspector inspector = null;
        try {
	    
	    tx = session.getTransaction();
	    tx.begin();
	    list = session.createQuery("from Inspector where firstname='" + firstname + "'").list();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return  list;
    }
     
     public List<Inspector> getInspectorByLastname(String lastname) {
	
	List<Inspector> list = new ArrayList<Inspector>();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        Inspector inspector = null;
        try {
	    
	    tx = session.getTransaction();
	    tx.begin();
	    list = session.createQuery("from Inspector where lastname='" + lastname + "'").list();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return  list;
    }
    
    
   
}
