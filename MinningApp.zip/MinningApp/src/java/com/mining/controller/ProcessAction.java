/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.controller;

import com.mining.Entities.Boiler;
import com.mining.Entities.Chairlift;
import com.mining.Entities.Lift;
import com.mining.Entities.Mine;
import com.mining.Entities.Region;
import com.mining.Entities.Shaft;
import com.mining.Entities.Winder;
import com.mining.EntitiesBean.BoilerControlLocal;
import com.mining.EntitiesBean.ChairliftControlLocal;
import com.mining.EntitiesBean.LiftControlLocal;
import com.mining.EntitiesBean.MineControlLocal;
import com.mining.EntitiesBean.RegionControlLocal;
import com.mining.EntitiesBean.ShaftControlLocal;
import com.mining.EntitiesBean.WinderControlLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.management.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ERavhengani
 */
public class ProcessAction extends HttpServlet {

    @EJB
    private ShaftControlLocal scl;

    @EJB
    private MineControlLocal mcl;

    @EJB
    private RegionControlLocal rcl;
    @EJB
    private WinderControlLocal wcl;

    @EJB
    private ChairliftControlLocal ccl;

    @EJB
    private LiftControlLocal lcl;

    @EJB
    private BoilerControlLocal bcl;

    private ProcessServlet serv = new ProcessServlet();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            List results;

            String action = request.getParameter("action");

            if (action.equalsIgnoreCase("search")) {
                String choice = request.getParameter("search-by");
                String search_str = request.getParameter("search_textfield");
               
                out.println("SEarching");

                if (choice != null) {
                    switch (choice) {
                        case "shaftNumber":
                          
                             Integer sNumber = Integer.parseInt(request.getParameter("search_textfield"));
                               results = scl.getShaftByNumber(sNumber);
                            int number_size = results.size();
                            out.println("Searching By Number: " + (number_size > 0 ? number_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (number_size > 0 ? number_size + " Found" : "No Item found "));
                            request.setAttribute("results", results);
                            break;
                        case "shaftName":
                            
                            results = scl.getShaftByName(search_str);
                            int name_size = results.size();
                            out.println("Searching By Shaft Name: " + (name_size > 0 ? name_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (name_size > 0 ? name_size + " Found" : "No Item found "));
                            request.setAttribute("results", results);
                            break;
                        case "mineName":
                            results = scl.getShaftByMine(search_str);
                            int mine_size = results.size();
                            out.println("Searching By Mine Name: " + (mine_size > 0 ? mine_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (mine_size > 0 ? mine_size + " Found" : "No Item found "));
                            request.setAttribute("results", results);
                            break;

                    }
                }
                if (scl != null) {
                    request.getRequestDispatcher("Displays/DisplayShaft.jsp").forward(request, response);
                } else{
                
                }
            }

            if (action.equalsIgnoreCase("go")) {
                String method = request.getParameter("edit-method");
                out.println("Choose The Row First To  : " + method);
                switch (method) {

                    case "add":
                        List<Region> reg = rcl.getRegions();
                        List<Mine> mine = mcl.getAllMine();
                        request.setAttribute("reg", reg);
                        request.setAttribute("mine", mine);
                        request.getRequestDispatcher("Registers/NewShaft.jsp").forward(request, response);

                        break;
                    case "delete":
                        String[] elphy = request.getParameterValues("elphy");
                        if (elphy != null) {
                            for (String data : elphy) {
                                if (serv.deleteStaff(elphy, request, response)) {

                                    Shaft shaft = (Shaft) scl.getShaftByNumber(Integer.parseInt(data)).get(0);
                                    out.print(shaft.getShaftDimensions());

                                    if (shaft != null) {

                                        scl.deleteShaft(Integer.parseInt(data));
                                        //shaft.setShaftName("masindi");
                                        // scl.updateShaft(shaft);
                                        List s = scl.getShafts();
                                        request.setAttribute("results", s);
                                        request.getRequestDispatcher("Displays/DisplayShaft.jsp").forward(request, response);
                                    } else {
                                        out.println("Staff is empty for:" + method);
                                    }
                                }
                            }// end of for each
                        }// end of if Null
                        break;
                    case "update":
                        String[] elphy2 = request.getParameterValues("elphy");
                        if (elphy2.length > 0) {
                            Shaft shaft = (Shaft) scl.getShaftByNumber(Integer.parseInt(elphy2[0])).get(0);
                            request.setAttribute("edit-shaft", shaft);
                            request.getRequestDispatcher("Update/UpdateShaft.jsp").forward(request, response);
                        } else {

                        }

                        break;
                    case "display":
                        String[] elphy3 = request.getParameterValues("elphy");
                        if (elphy3.length > 0) {
                            Shaft shaft = (Shaft) scl.getShaftByNumber(Integer.parseInt(elphy3[0])).get(0);
                            request.setAttribute("edit-shaft", shaft);
                            request.getRequestDispatcher("Viewing/ViewShaft.jsp").forward(request, response);
                        } else {

                        }

                        break;

                    default:
                        break;
                }
            }

            if (action.equalsIgnoreCase("add")) {
                out.println("Adding New Item");
                List<Shaft> list = new ArrayList<>();
                String qwert = request.getParameter("action");
                Shaft sft = serv.Register(request, response);
                //Mine mine = serv.addMine(request, response);
                //Region region = serv.addRegion(request, response);

                out.println("gathering staff");

                //rcl.addRegion(region);
                // mcl.addMine(mine);
                scl.addShaft(sft);
                out.println("adding staff");
                list.add(sft);
                request.setAttribute("results", list);
                request.getRequestDispatcher("Displays/DisplayShaft.jsp").forward(request, response);

            } else if (action.equalsIgnoreCase("update")) {
                out.println("Adding New Item");
                List<Shaft> list = new ArrayList<>();
                String qwert = request.getParameter("action");
                Shaft sft = serv.Register(request, response);
                Mine mine = serv.addMine(request, response);
                Region region = serv.addRegion(request, response);

                out.println("gathering staff");

                rcl.updateRegion(region);
                mcl.updateMine(mine);
                scl.updateShaft(sft);
                out.println("adding staff");
                list.add(sft);
                request.setAttribute("results", list);
                request.getRequestDispatcher("Displays/DisplayShaft.jsp").forward(request, response);
            } else if (action.equalsIgnoreCase("delete")) {

            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(ProcessAction.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(ProcessAction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
