/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.controller;

import com.mining.Entities.*;
import com.mining.service.InspectorService;
import com.mining.service.RegionService;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author LQwabe
 */
public class InspectorController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static String LIST_INSPECTORS = "/list_inspectors.jsp";
    private static String INSERT = "/createInspector.jsp";
    private static String EDIT = "/editInspector.jsp";
    private InspectorService service;
    private RegionService regionservice;

    /**
     *
     */
    public InspectorController() {
	super();
	service = new InspectorService();
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String forward = "";
	String action = request.getParameter("action");

	if (action.equalsIgnoreCase("listInspectors")) {
	    forward = LIST_INSPECTORS;
	  
	    request.setAttribute("inspectors", service.getAllInspectors());
	}

	if (action.equalsIgnoreCase("search")) {
	    forward = INSERT;

//	    String searchName = request.getParameter("searchName");
//			Manager manager = service.getManagerByUsername(searchName);
//			List<Manager> managers = new ArrayList<Manager>();
//			managers.add(manager);
//			request.setAttribute("managers", managers);
	}

	if (action.equalsIgnoreCase("insert")) {

	    forward = INSERT;

	}

	if (action.equalsIgnoreCase("edit")) {

	    forward = EDIT;
	    String username = request.getParameter("username");
	    request.setAttribute("inspector", service.getInspectorByUsername(username));

	}

	if (action.equalsIgnoreCase("delete")) {
	    forward = LIST_INSPECTORS;
	    String username = request.getParameter("username");
	    service.deleteInspector(username);

	    request.setAttribute("inspectors", service.getAllInspectors());
	}

	RequestDispatcher view = request.getRequestDispatcher(forward);
	view.forward(request, response);
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {
	response.setContentType("text/html;charset=UTF-8");
	PrintWriter out = response.getWriter();
	String forward = "";
	forward = LIST_INSPECTORS;
	String username = request.getParameter("username");
	String password = request.getParameter("password");
	String firstName = request.getParameter("firstName");
	String lastName = request.getParameter("lastName");
	String emailAddress = request.getParameter("email");
	String regionName = request.getParameter("regionName");

	Region region = new Region();
	region.setRegionName(regionName);
	Inspector inspector = new Inspector();
	inspector.setUsername(username);
	inspector.setPassword(password);
	inspector.setFirstname(firstName);
	inspector.setLastname(lastName);
	inspector.setEmailAddress(emailAddress);
	inspector.setRegionName(region);

	InspectorService inspectorService = new InspectorService();
	inspectorService.updateInspector(inspector);

	RequestDispatcher view = request.getRequestDispatcher(forward);
	view.forward(request, response);

    }

}
