/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.controller;

import com.mining.Entities.Boiler;
import com.mining.Entities.Chairlift;
import com.mining.Entities.Lift;
import com.mining.Entities.Mine;
import com.mining.Entities.Region;
import com.mining.Entities.Shaft;
import com.mining.Entities.Winder;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ERavhengani
 */
@WebServlet(name = "ProcessServlet", urlPatterns = {"/ProcessServlet"})
public class ProcessServlet extends HttpServlet {

    public ProcessServlet() {
    }

    public Shaft Register(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Shaft s = new Shaft();

        s.setShaftNumber(Integer.parseInt(request.getParameter("shaft_number")));
        s.setShaftName(request.getParameter("shaft_name"));
        s.setMineNumber(new Mine(Integer.parseInt(request.getParameter("mine_number"))));
        s.setMineName(request.getParameter("mine_name"));
        s.setRegionName(new Region(request.getParameter("region_name")));
        s.setNewShaft(request.getParameter("new_shaft"));
        s.setShaftStatus(request.getParameter("shaft_status"));
        s.setShaftShape(request.getParameter("shaft_shape"));
        s.setShaftDimensions(request.getParameter("shaft_dimensions"));
        s.setVentilationFlow(request.getParameter("ventilation_flow"));
        s.setShaftCondition(request.getParameter("shaft_condition"));
        s.setWaterCondition(request.getParameter("water_condition"));
        s.setAvgPersonTransportedPerDay(Float.parseFloat(request.getParameter("avg_person_transported_per_day")));
        s.setVerticalShaftDepth(request.getParameter("vertical_shaft_depth"));
        s.setInclinationLength(Float.parseFloat(request.getParameter("inclination_length")));
        s.setInclinationAngle(Float.parseFloat(request.getParameter("inclination_angle")));
        s.setNumberOfRopes(Integer.parseInt(request.getParameter("number_of_ropes")));
        return s;

    }

    public Winder RegisterWinder(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        Winder winder = new Winder();
        
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
       
        winder.setWinderNumber(Integer.parseInt(request.getParameter("winder_number")));
        winder.setMineNumber(new Mine(Integer.parseInt(request.getParameter("mine_number"))));
        winder.setMineName(request.getParameter("mine_name"));
        winder.setRegionName(new Region(request.getParameter("region_name")));
        winder.setPreviousRegion(request.getParameter("previous_region"));
        winder.setNewWinder(request.getParameter("new_winder"));
        winder.setPreviousNumber(Integer.parseInt(request.getParameter("previous_number")));
        winder.setDateOfApplication(format.parse(request.getParameter("date_of_application")));
        winder.setWinderType(request.getParameter("winder_type"));
        winder.setShaftNumber(new Shaft(Integer.parseInt(request.getParameter("shaft_number"))));
        winder.setShaftName(request.getParameter("shaft_name"));
        winder.setWinderStatus(request.getParameter("winder_status"));
        winder.setWinderClass(request.getParameter("winder_class"));
        winder.setDatePermitIssued(format.parse(request.getParameter("date_permit_issued")));
        winder.setTopClearance(Integer.parseInt(request.getParameter("top_clearance")));
        winder.setBottomClearance(Integer.parseInt(request.getParameter("bottom_clearance")));
        winder.setSheaveDiameter(Float.parseFloat(request.getParameter("sheave_diameter")));
        winder.setSheaveOrRopeRatio(Float.parseFloat(request.getParameter("sheave_or_rope_ratio")));
        winder.setMaxNoOfPersons(Integer.parseInt(request.getParameter("max_no_of_persons")));
        winder.setMaxMassMaterial(Float.parseFloat(request.getParameter("max_mass_material")));
        winder.setMaxMassMineral(Float.parseFloat(request.getParameter("max_mass_mineral")));
        winder.setDepthIndicateType(request.getParameter("depth_indicate_type"));
        winder.setManufacturer(request.getParameter("manufacturer"));
        winder.setYearManufactured(Integer.parseInt(request.getParameter("year_manufactured")));
        winder.setNumberOfMotorsUsed(Integer.parseInt(request.getParameter("number_of_motors_used")));
        winder.setPrimeMover(request.getParameter("prime_mover"));
        winder.setPowerRating(request.getParameter("power_rating"));
        winder.setRpm(request.getParameter("rpm"));
        winder.setSupplyVoltage(request.getParameter("supply_voltage"));
        winder.setMgSet(request.getParameter("mg_set"));

        return winder;

    }

    public Chairlift RegisterChairlift(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Chairlift c = new Chairlift();
        c.setChairliftNumber(Integer.parseInt(request.getParameter("chairlift_number")));
        c.setMineNumber(new Mine(Integer.parseInt(request.getParameter("mine_number"))));
        c.setMineName(request.getParameter("mine_name"));
        c.setRegionName(new Region(request.getParameter("region_name")));
        c.setNewChairlift(request.getParameter("new_chairlift"));
        c.setPreviousRegion(request.getParameter("previous_region"));
        c.setLocation(request.getParameter("location"));
        c.setShaftNumber(new Shaft(Integer.parseInt(request.getParameter("shaft_number"))));
        c.setShaftName(request.getParameter("shaft_name"));
        c.setManufacturer(request.getParameter("manufacturer"));
        c.setYearManufactured(Integer.parseInt(request.getParameter("year_manufactured")));
        c.setYearInstalled(Integer.parseInt(request.getParameter("year_installed")));
        c.setDistanceBetweenDriveAndReturnSheave(Float.parseFloat(request.getParameter("distance_between_drive_and_return_sheave")));
        c.setMaxNoOfChair(Float.parseFloat(request.getParameter("max_no_of_chair")));
        c.setDistanceBetweenChairs(Float.parseFloat(request.getParameter("distance_between_chairs")));
        c.setChairSpeed(Float.parseFloat(request.getParameter("chair_speed")));
        c.setCapacity(Integer.parseInt(request.getParameter("capacity")));
        c.setMaxInclinationAngle(Float.parseFloat(request.getParameter("max_inclination_angle")));
        c.setChairConnection(request.getParameter("chair_connection"));
        c.setChairType(request.getParameter("chair_type"));
        c.setPowerOfDrivingMotor(Float.parseFloat(request.getParameter("power_of_driving_motor")));
        c.setMainBreakType(request.getParameter("main_break_type"));
        c.setBackupBreakType(request.getParameter("backup_break_type"));
        c.setInstallationType(request.getParameter("installation_type"));
        c.setHaulingChainRopeParticulars(request.getParameter("hauling_chain_rope_particulars"));
        c.setDrawings(request.getParameter("drawings"));
        c.setManufacturerSpecification(request.getParameter("manufacturer_specification"));
        c.setRopeAndChainsParticulars(request.getParameter("rope_and_chains_particulars"));
        c.setRopeTensioningDevice(request.getParameter("rope_tensioning_device"));
        c.setSpecialCarries(request.getParameter("special_carries"));
        return c;
    }

    public Lift RegisterLift(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Lift l = new Lift();

        l.setLiftNumber(Integer.parseInt(request.getParameter("lift_number")));
        l.setMineNumber(new Mine(Integer.parseInt(request.getParameter("mine_number"))));
        l.setMineName(request.getParameter("mine_name"));
        l.setRegionName(new Region(request.getParameter("region_name")));
        l.setNewLift(request.getParameter("new_lift"));
        l.setLiftStatus(request.getParameter("lift_status"));
        l.setIsLiftInstalledInAShaft(request.getParameter("is_lift_installed_in_a_shaft"));
        l.setShaftNumber(new Shaft(Integer.parseInt(request.getParameter("shaft_number"))));
        l.setConveyanceType(request.getParameter("conveyance_type"));
        l.setConveyanceMass(Float.parseFloat(request.getParameter("conveyance_mass")));
        l.setLoadMass(Float.parseFloat(request.getParameter("load_mass")));
        l.setLoadType(request.getParameter("load_type"));
        l.setWindLength(Float.parseFloat(request.getParameter("wind_length")));
        l.setMaxWindingSpeed(Float.parseFloat(request.getParameter("max_winding_speed")));
        l.setNumberOfLandings(Integer.parseInt(request.getParameter("number_of_landings")));

        return l;

    }

    public Boiler RegisterBoiler(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Boiler b = new Boiler();
        
        b.setBoilerNumber(Integer.parseInt(request.getParameter("boiler_number")));
        b.setMineNumber(new Mine(Integer.parseInt(request.getParameter("mine_number"))));
        b.setRegionName(new Region(request.getParameter("region_name")));
        b.setMineName(request.getParameter("mine_name"));
        b.setNewBoiler(request.getParameter("new_boiler"));
        b.setPreviousRegion(request.getParameter("previous_region"));
        b.setLocation(request.getParameter("location"));
        b.setTypeOfBoiler(request.getParameter("type_of_boiler"));
        b.setManufacturer(request.getParameter("manufacturer"));
        b.setCountryOfOrigion(request.getParameter("country_of_origion"));
        b.setSerialNumber(request.getParameter("serial_number"));
        b.setYearManufactured(Integer.parseInt(request.getParameter("year_manufactured")));
        b.setYearInstalled(Integer.parseInt(request.getParameter("year_installed")));
        b.setMaxAuthorizedWorkingPressure(Float.parseFloat(request.getParameter("max_authorized_working_pressure")));
        b.setEvaporativeCapacity(request.getParameter("evaporative_capacity"));
        b.setSourceOfHeat(request.getParameter("source_of_heat"));
        b.setBoilerStatus(request.getParameter("boiler_status"));

        return b;
    }

    public Mine addMine(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Mine mine = new Mine();
        mine.setMineName(request.getParameter("mine_name"));
        mine.setMineNumber(Integer.parseInt(request.getParameter("mine_number")));
        mine.setRegionName(new Region(request.getParameter("region_name")));
        return mine;
    }

    public Region addRegion(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Region region = new Region();
        region.setRegionName(request.getParameter("region_name"));
        return region;
    }

    public boolean deleteStaff(String[] ids, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        return true;
    }
    public boolean deleteW(String[] ids, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        return true;
    }

    public boolean deleteC(String[]ids, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
    
        return true;
    }
    public boolean deleteL(String[]ids, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
    
        return true;
    }
    public boolean deleteB(String[]idl, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
    
        return true;
    }
}
