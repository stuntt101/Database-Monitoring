/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mining.Entities.*;
import com.mining.service.ManagerService;

/**
 *
 * @author LQwabe
 */
public class RegisterManager extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
	String password = request.getParameter("password");
	String firstName = request.getParameter("firstName");
	String lastName = request.getParameter("lastName");
	String emailAddress = request.getParameter("email");
	String mineName = request.getParameter("mineName");
	Integer mineNumber = Integer.parseInt(request.getParameter("mineNumber"));
	String regionName = request.getParameter("regionName");

	Mine mine = new Mine();
	Region region = new Region();
	region.setRegionName(regionName);
	mine.setMineNumber(mineNumber);

        Manager manager = new Manager(username, password, firstName, lastName, mineName);
        manager.setRegionName(region);
        manager.setMineNumber(mine);
	manager.setEmailAddress(emailAddress);

        try {
            ManagerService managerService = new ManagerService();
            boolean result = managerService.addManager(manager);
            
            
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Registration Successful</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<center>");
            if (result) {

                request.getRequestDispatcher("list_managers.jsp").forward(request, response);
            } else {
                out.println("<h1>Registration Failed</h1>");
                out.println("To try again<a href=createManager.jsp>Click here</a>");
            }
            out.println("</center>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }

}
