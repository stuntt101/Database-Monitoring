/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.controller;

import java.io.IOException;
import java.util.*;
import java.io.PrintWriter;
import com.mining.Entities.*;
import com.mining.service.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author LQwabe
 */
public class ManagerController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static String LIST_MANAGERS = "/list_managers.jsp";
    private static String INSERT = "/createManager.jsp";
    private static String EDIT = "/editManager.jsp";
    private ManagerService service;
    private MineService mineservice;
    private RegionService regionservice;

    /**
     *
     */
    public ManagerController() {
	super();
	service = new ManagerService();
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String forward = "";
	String action = request.getParameter("action");

	if (action.equalsIgnoreCase("listManagers")) {
	    forward = LIST_MANAGERS;
	    request.setAttribute("managers", service.getAllManagers());
	}

	if (action.equalsIgnoreCase("search")) {
	    forward = INSERT;

	}
	
	if (action.equalsIgnoreCase("insert")) {

	    forward = INSERT;

	}

	if (action.equalsIgnoreCase("edit")) {

	    forward = EDIT;

	    String username = request.getParameter("username");
	    Manager manager = service.getManagerByUsername(username);
	    request.setAttribute("manager", manager);

	}


	if (action.equalsIgnoreCase("delete")) {
	    forward = LIST_MANAGERS;
	    String username = request.getParameter("username");
	    service.deleteManager(username);

	    request.setAttribute("managers", service.getAllManagers());
	}

	RequestDispatcher view = request.getRequestDispatcher(forward);
	view.forward(request, response);
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {
	response.setContentType("text/html;charset=UTF-8");
	PrintWriter out = response.getWriter();
	String forward = "";
	forward = LIST_MANAGERS;
	String username = request.getParameter("username");
	String password = request.getParameter("password");
	String firstName = request.getParameter("firstName");
	String lastName = request.getParameter("lastName");
	String emailAddress = request.getParameter("email");
	String mineName = request.getParameter("mineName");
	Integer mineNumber = Integer.parseInt(request.getParameter("mineNumber"));
	String regionName = request.getParameter("regionName");

	Mine mine = new Mine();
	Region region = new Region();
	region.setRegionName(regionName);
	mine.setMineNumber(mineNumber);

	Manager manager = new Manager(username, password, firstName, lastName, mineName);
	manager.setRegionName(region);
	manager.setMineNumber(mine);
	manager.setEmailAddress(emailAddress);

	ManagerService managerService = new ManagerService();
	managerService.updateManager(manager);

	RequestDispatcher view = request.getRequestDispatcher(forward);
	view.forward(request, response);

    }

}
