package com.mining.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mining.service.ManagerService;
import com.mining.service.InspectorService;
import com.mining.Entities.*;
import com.mining.service.LoginService;

/**
 *
 * @author LQwabe
 */
public class LoginServlet extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

	 String username = request.getParameter("username");	
	 String password = request.getParameter("password");
	 LoginService loginService = new LoginService();
	 ManagerService managerService = new ManagerService();
	 InspectorService inspectorService = new InspectorService();
	 boolean result_admin = loginService.authenticateAdmin(username, password);
	 boolean result_manager = loginService.authenticateManager(username, password);
	 boolean result_inspector = loginService.authenticateInspector (username, password);
	 Admin admin = loginService.getAdminByUsername(username);
	 Manager manager = managerService.getManagerByUsername(username);
	 Inspector  inspector = inspectorService.getInspectorByUsername(username);
	 
	 
	 
	 if(result_admin == true){
		 request.getSession().setAttribute("admin", admin);		
		 response.sendRedirect("admin_home.jsp");
	 }
	 
	 else if(result_manager== true){
		 request.getSession().setAttribute("manager", manager);		
		 response.sendRedirect("manager_home.jsp");
	 }
	 
	 else if(result_inspector== true){
		 request.getSession().setAttribute("inspector", inspector);		
		 response.sendRedirect("inspector_home.jsp");
	 }
	 else{
		 response.sendRedirect("error.jsp");
	 }
}

}