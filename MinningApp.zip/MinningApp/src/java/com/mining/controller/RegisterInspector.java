/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.controller;
import com.mining.Entities.*;
import com.mining.service.InspectorService;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author LQwabe
 */
public class RegisterInspector extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {
	response.setContentType("text/html;charset=UTF-8");
	PrintWriter out = response.getWriter();

	String username = request.getParameter("username");
	String password = request.getParameter("password");
	String firstName = request.getParameter("firstName");
	String lastName = request.getParameter("lastName");
	String emailAddress = request.getParameter("email");
	String regionName = request.getParameter("regionName");

	Region region = new Region();
	region.setRegionName(regionName);

	Inspector inspector = new Inspector();
	inspector.setUsername(username);
	inspector.setPassword(password);
	inspector.setFirstname(firstName);
	inspector.setLastname(lastName);
	inspector.setEmailAddress(emailAddress);
	inspector.setRegionName(region);

	try {
	    InspectorService inspectorService = new InspectorService();
	    boolean result = inspectorService.addInspector(inspector);

	    out.println("<html>");
	    out.println("<head>");
	    out.println("<title>Registration Successful</title>");
	    out.println("</head>");
	    out.println("<body>");
	    out.println("<center>");
	    if (result) {

		request.getRequestDispatcher("list_inspectors.jsp").forward(request, response);
	    } else {
		out.println("<h1>Registration Failed</h1>");
		out.println("To try again<a href=createInspector.jsp>Click here</a>");
	    }
	    out.println("</center>");
	    out.println("</body>");
	    out.println("</html>");
	} finally {
	    out.close();
	}
    }

}
