/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.controller;

import com.mining.Entities.Boiler;
import com.mining.Entities.Mine;
import com.mining.Entities.Region;
import com.mining.Entities.Shaft;
import com.mining.EntitiesBean.BoilerControlLocal;
import com.mining.EntitiesBean.MineControlLocal;
import com.mining.EntitiesBean.RegionControlLocal;
import com.mining.EntitiesBean.ShaftControlLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ERavhengani
 */
@WebServlet(name = "ProcessActionB", urlPatterns = {"/ProcessActionB"})
public class ProcessActionB extends HttpServlet {

    @EJB
    private MineControlLocal mcl;

    @EJB
    private RegionControlLocal rcl;

    @EJB
    private BoilerControlLocal bcl;

    private ProcessServlet serv = new ProcessServlet();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */

            List results4;

            String action = request.getParameter("action");

            if (action.equalsIgnoreCase("search")) {
                String choice = request.getParameter("search-by");
                String search_str = request.getParameter("search_textfield");

                out.println("SEarching");

                if (choice != null) {
                    switch (choice) {
                        case "boilerNumber":
                            Integer sNumber = Integer.parseInt(request.getParameter("search_textfield"));
                            results4 = bcl.getBoilerByNumber(sNumber);
                            int number_size = results4.size();
                            out.println("Searching By Number: " + (number_size > 0 ? number_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (number_size > 0 ? number_size + " Found" : "No Item found "));
                            request.setAttribute("results4", results4);
                            break;
                        case "boilerStatus":
                            results4 = bcl.getBoilerByStatus(search_str);
                            int name_size = results4.size();
                            out.println("Searching By Shaft Name: " + (name_size > 0 ? name_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (name_size > 0 ? name_size + " Found" : "No Item found "));
                            request.setAttribute("results4", results4);
                            break;
                        case "mineName":
                            results4 = bcl.getBoilerByMine(search_str);
                            int mine_size = results4.size();
                            out.println("Searching By Mine Name: " + (mine_size > 0 ? mine_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (mine_size > 0 ? mine_size + " Found" : "No Item found "));
                            request.setAttribute("results4", results4);
                            break;

                    }
                }
                if (bcl != null) {
                    request.getRequestDispatcher("Displays/DisplayBoiler.jsp").forward(request, response);
                }
            }

            if (action.equalsIgnoreCase("go")) {
                String method = request.getParameter("edit-method");
                out.println("Choose The Row First To  : :" + method);
                switch (method) {

                    case "add":
                        List<Region> reg = rcl.getRegions();
                        List<Mine> mine = mcl.getAllMine();

                        request.setAttribute("reg", reg);
                        request.setAttribute("mine", mine);

                        request.getRequestDispatcher("Registers/NewBoiler.jsp").forward(request, response);
                        break;
                    case "delete":
                        String[] elphy = request.getParameterValues("elphy");

                        if (elphy != null) {
                            for (String data4 : elphy) {
                                if (serv.deleteStaff(elphy, request, response)) {
                                    Boiler boiler = (Boiler) bcl.getBoilerByNumber(Integer.parseInt(data4)).get(0);
                                    out.print(boiler.getBoilerStatus());
                                    if (boiler != null) {
                                        bcl.deleteBoiler(Integer.parseInt(data4));
                                        List b = bcl.getBoilers();
                                        request.setAttribute("results4", b);
                                        request.getRequestDispatcher("Displays/DisplayBoiler.jsp").forward(request, response);
                                    } else {
                                        out.println("Boiler Empty :" + method);

                                    }
                                }
                            }//end of for boilerDel
                        }//end of boilerDel

                        break;
                    case "update":
                        String[] elphy2 = request.getParameterValues("elphy");
                        if (elphy2.length > 0) {
                            Boiler boiler = (Boiler) bcl.getBoilerByNumber(Integer.parseInt(elphy2[0])).get(0);
                            request.setAttribute("edit-boiler", boiler);
                            request.getRequestDispatcher("Update/UpdateBoiler.jsp").forward(request, response);
                        } else {

                        }
                        break;
                    case "display":
                        String[] elphy3 = request.getParameterValues("elphy");
                        if (elphy3.length > 0) {
                            Boiler boiler = (Boiler) bcl.getBoilerByNumber(Integer.parseInt(elphy3[0])).get(0);
                            request.setAttribute("edit-boiler", boiler);
                            request.getRequestDispatcher("Viewing/ViewBoiler.jsp").forward(request, response);
                        } else {

                        }

                        break;

                    default:
                        break;
                }
            }

            if (action.equalsIgnoreCase("add")) {
                out.println("Adding New Item");
                List<Boiler> list4 = new ArrayList<>();
                String qwert = request.getParameter("action");
                // Mine mine = serv.addMine(request, response);
                // Region region = serv.addRegion(request, response);
                Boiler boiler = serv.RegisterBoiler(request, response);

                out.println("gathering staff");
                //rcl.addRegion(region);
                // mcl.addMine(mine); 
                bcl.addBoiler(boiler);
                out.println("adding staff");
                list4.add(boiler);
                request.setAttribute("results4", list4);
                request.getRequestDispatcher("Displays/DisplayBoiler.jsp").forward(request, response);

            } else if (action.equalsIgnoreCase("update")) {
                out.println("Adding New Item");
                List<Boiler> list4 = new ArrayList<>();
                String qwert = request.getParameter("action");
                Boiler boiler = serv.RegisterBoiler(request, response);

                out.println("gathering staff");

                bcl.updateBoiler(boiler);
                out.println("adding staff");
                list4.add(boiler);
                request.setAttribute("results4", list4);
                request.getRequestDispatcher("Displays/DisplayBoiler.jsp").forward(request, response);
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
