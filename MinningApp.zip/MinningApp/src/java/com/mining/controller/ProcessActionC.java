/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.controller;

import com.mining.Entities.Chairlift;
import com.mining.Entities.Mine;
import com.mining.Entities.Region;
import com.mining.Entities.Shaft;
import com.mining.EntitiesBean.ChairliftControlLocal;
import com.mining.EntitiesBean.MineControlLocal;
import com.mining.EntitiesBean.RegionControlLocal;
import com.mining.EntitiesBean.ShaftControlLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ERavhengani
 */
@WebServlet(name = "ProcessActionC", urlPatterns = {"/ProcessActionC"})
public class ProcessActionC extends HttpServlet {

    @EJB
    private ShaftControlLocal scl;
    @EJB
    private MineControlLocal mcl;

    @EJB
    private RegionControlLocal rcl;

    @EJB
    private ChairliftControlLocal ccl;

    private ProcessServlet serv = new ProcessServlet();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            List results2;

            String action = request.getParameter("action");

            if (action.equalsIgnoreCase("search")) {
                String choice = request.getParameter("search-by");
                String search_str = request.getParameter("search_textfield");

                out.println("SEarching");

                if (choice != null) {
                    switch (choice) {
                        case "chairliftNumber":
                            Integer sNumber = Integer.parseInt(request.getParameter("search_textfield"));
                            results2 = ccl.getChairliftByNumber(sNumber);
                            int number_size = results2.size();
                            out.println("Searching By Number: " + (number_size > 0 ? number_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (number_size > 0 ? number_size + " Found" : "No Item found "));
                            request.setAttribute("results2", results2);

                            break;
                        case "drawings":
                            results2 = ccl.getChairliftByDrawings(search_str);
                            int name_size = results2.size();
                            out.println("Searching By Shaft Name: " + (name_size > 0 ? name_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (name_size > 0 ? name_size + " Found" : "No Item found "));
                            request.setAttribute("results2", results2);
                            break;
                        case "mineName":
                            results2 = ccl.getChairliftByMine(search_str);
                            int mine_size = results2.size();
                            out.println("Searching By Mine Name: " + (mine_size > 0 ? mine_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (mine_size > 0 ? mine_size + " Found" : "No Item found "));
                            request.setAttribute("results2", results2);
                            break;

                    }
                }
                if (ccl != null) {
                    request.getRequestDispatcher("Displays/DisplayChairlift.jsp").forward(request, response);
                }
            }

            if (action.equalsIgnoreCase("go")) {
                String method = request.getParameter("edit-method");
                out.println("Choose The Row First To :" + method);
                switch (method) {

                    case "add":
                        List<Region> reg = rcl.getRegions();
                        List<Mine> mine = mcl.getAllMine();
                        List<Shaft> shaft = scl.getShafts();
                        request.setAttribute("reg", reg);
                        request.setAttribute("mine", mine);
                        request.setAttribute("shaft", shaft);
                        request.getRequestDispatcher("Registers/NewChairlift.jsp").forward(request, response);

                        break;
                    case "delete":
                        String[] elphy = request.getParameterValues("elphy");

                        if (elphy != null) {
                            for (String data2 : elphy) {
                                if (serv.deleteStaff(elphy, request, response)) {
                                    Chairlift chairlift = (Chairlift) ccl.getChairliftByNumber(Integer.parseInt(data2)).get(0);
                                    out.print(chairlift.getChairType());
                                    if (chairlift != null) {
                                        ccl.deleteChairlift(Integer.parseInt(data2));
                                        List c = ccl.getChairlifts();
                                        request.setAttribute("results2", c);
                                        request.getRequestDispatcher("Displays/DisplayChairlift.jsp").forward(request, response);

                                    } else {
                                        out.println("Chairlift Empty:" + method);
                                    }
                                }

                            }//end of for chairliftDel
                        } //end of chairliftDel

                        break;
                    case "update":
                        String[] elphy2 = request.getParameterValues("elphy");
                        if (elphy2.length > 0) {
                            Chairlift chairlift = (Chairlift) ccl.getChairliftByNumber(Integer.parseInt(elphy2[0])).get(0);
                            request.setAttribute("edit-chairlift", chairlift);
                            request.getRequestDispatcher("Update/UpdateChairlift.jsp").forward(request, response);
                        } else {

                        }
                        break;
                    case "display":
                        String[] elphy3 = request.getParameterValues("elphy");
                        if (elphy3.length > 0) {
                            Chairlift chairlift = (Chairlift) ccl.getChairliftByNumber(Integer.parseInt(elphy3[0])).get(0);
                            request.setAttribute("edit-chairlift", chairlift);
                            request.getRequestDispatcher("Viewing/ViewChairlift.jsp").forward(request, response);
                        } else {

                        }

                        break;

                    default:
                        break;
                }
            }

            if (action.equalsIgnoreCase("add")) {
                out.println("Adding New Item");
                List<Chairlift> list2 = new ArrayList<>();
                String qwert = request.getParameter("action");
                //Mine mine = serv.addMine(request, response);
                //Region region = serv.addRegion(request, response);
                Chairlift chair = serv.RegisterChairlift(request, response);

                out.println("gathering staff");
                // rcl.addRegion(region);
                //mcl.addMine(mine);
                ccl.addChairlift(chair);

                out.println("adding staff");
                list2.add(chair);
                request.setAttribute("results2", list2);
                request.getRequestDispatcher("Displays/DisplayChairlift.jsp").forward(request, response);
            } else if (action.equalsIgnoreCase("update")) {
                out.println("Adding New Item");
                List<Chairlift> list2 = new ArrayList<>();
                String qwert = request.getParameter("action");
                Chairlift chair = serv.RegisterChairlift(request, response);

                out.println("gathering staff");

                ccl.updateChairlift(chair);
                out.println("adding staff");
                list2.add(chair);
                request.setAttribute("results2", list2);
                request.getRequestDispatcher("Displays/DisplayChairlift.jsp").forward(request, response);
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
