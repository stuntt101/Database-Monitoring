/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.controller;

import com.mining.Entities.Mine;
import com.mining.Entities.Region;
import com.mining.Entities.Shaft;
import com.mining.Entities.Winder;
import com.mining.EntitiesBean.MineControlLocal;
import com.mining.EntitiesBean.RegionControlLocal;
import com.mining.EntitiesBean.ShaftControlLocal;
import com.mining.EntitiesBean.WinderControlLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ERavhengani
 */
@WebServlet(name = "ProcessActionW", urlPatterns = {"/ProcessActionW"})
public class ProcessActionW extends HttpServlet {

    @EJB
    private ShaftControlLocal scl;

    @EJB
    private MineControlLocal mcl;

    @EJB
    private RegionControlLocal rcl;
    @EJB
    private WinderControlLocal wcl;

    private ProcessServlet serv = new ProcessServlet();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */

            List results1;

            String action = request.getParameter("action");

            if (action.equalsIgnoreCase("search")) {
                String choice = request.getParameter("search-by");
                String search_str = request.getParameter("search_textfield");
  
                out.println("SEarching");

                if (choice != null) {
                    switch (choice) {
                        case "winderNumber":
                               Integer sNumber = Integer.parseInt(request.getParameter("search_textfield"));
                            results1 = wcl.getWinderByNumber(sNumber);
                            int number_size = results1.size();
                            out.println("Searching By Number: " + (number_size > 0 ? number_size + "Found" : "No items found"));
                            request.setAttribute("results_message", (number_size > 0 ? number_size + " Found" : "No Item found "));
                            request.setAttribute("results1", results1);

                            break;
                        case "winderClass":
                            results1 = wcl.getWinderByClass(search_str);
                            int name_size = results1.size();
                            out.println("Searching By winder Name: " + (name_size > 0 ? name_size + "Found" : "No items found"));
                            request.setAttribute("results1", results1);
                            break;
                        case "mineName":
                            results1 = wcl.getWinderByMine(search_str);
                            int mine_size = results1.size();
                            out.println("Searching By Mine Name: " + (mine_size > 0 ? mine_size + "Found" : "No items found"));
                             request.setAttribute("results_message", (mine_size > 0 ? mine_size + " Found" : "No Item found "));
                            request.setAttribute("results1", results1);
                            break;

                    }
                }
                if (wcl != null) {
                    request.getRequestDispatcher("Displays/DisplayWinder.jsp").forward(request, response);
                }
            }

            if (action.equalsIgnoreCase("go")) {
                String method = request.getParameter("edit-method");
                out.println("Choose The Row First To  :" + method);
                switch (method) {
                    case "add":
                        List<Region> reg = rcl.getRegions();
                        List<Mine> mine = mcl.getAllMine();
                        List<Shaft> shaft = scl.getShafts();
                        request.setAttribute("reg", reg);
                        request.setAttribute("mine", mine);
                        request.setAttribute("shaft", shaft);

                        request.getRequestDispatcher("Registers/NewWinders.jsp").forward(request, response);
                        break;
                    case "delete":
                        String[] elphy = request.getParameterValues("elphy");

                        if (elphy != null) {
                            for (String data1 : elphy) {
                                if (serv.deleteStaff(elphy, request, response)) {
                                    Winder winder = (Winder) wcl.getWinderByNumber(Integer.parseInt(data1)).get(0);
                                    out.print(winder.getWinderType());

                                    if (winder != null) {
                                        wcl.deleteWinder(Integer.parseInt(data1));
                                        List w = wcl.getWinders();
                                        request.setAttribute("results1", w);
                                        request.getRequestDispatcher("Displays/DisplayWInder.jsp").forward(request, response);

                                    } else {
                                        out.println("Winder Empty :" + method);
                                    }
                                }
                            }//end of for winderDel
                        }//end of winderDel
                        break;
                    case "update":
                        String[] elphy2 = request.getParameterValues("elphy");
                        if (elphy2.length > 0) {
                            Winder winder = (Winder) wcl.getWinderByNumber(Integer.parseInt(elphy2[0])).get(0);
                            request.setAttribute("edit-winder", winder);
                            request.getRequestDispatcher("Update/UpdateWinder.jsp").forward(request, response);
                        } else {

                        }

                        break;
                    case "display":
                        String[] elphy3 = request.getParameterValues("elphy");
                        if (elphy3.length > 0) {
                            Winder winder = (Winder) wcl.getWinderByNumber(Integer.parseInt(elphy3[0])).get(0);
                            request.setAttribute("edit-winder", winder);
                            request.getRequestDispatcher("Viewing/ViewWinder.jsp").forward(request, response);
                        } else {

                        }
                        break;

                    default:
                        break;
                }
            }

            if (action.equalsIgnoreCase("add")) {
                out.println("adding new item..");
                List<Winder> list1 = new ArrayList<>();
                String qwert = request.getParameter("action");
                // Mine mine = serv.addMine(request, response);
                // Region region = serv.addRegion(request, response);

                Winder wind = serv.RegisterWinder(request, response);

                out.println("gathering staff");
                // rcl.addRegion(region);
                // mcl.addMine(mine);

                wcl.addWinder(wind);
                out.println("adding staff");
                list1.add(wind);
                request.setAttribute("results1", list1);
                request.getRequestDispatcher("Displays/DisplayWinder.jsp").forward(request, response);
            } else if (action.equalsIgnoreCase("update")) {
                out.println("Adding New Item");
                List<Winder> list1 = new ArrayList<>();
                String qwert = request.getParameter("action");
                Winder wind = serv.RegisterWinder(request, response);

                out.println("gathering staff");

                wcl.updateWinder(wind);
                out.println("adding staff");
                list1.add(wind);
                request.setAttribute("results1", list1);
                request.getRequestDispatcher("Displays/DisplayWinder.jsp").forward(request, response);
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(ProcessActionW.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(ProcessActionW.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
