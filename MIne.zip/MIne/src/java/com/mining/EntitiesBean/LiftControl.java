/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Lift;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author ERavhengani
 */
@Stateless
public class LiftControl implements LiftControlLocal {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
    @PersistenceContext
    private EntityManager em;

    @Override
    public void addLift(Lift lift) {
    em.persist(lift);
    }

    @Override
    public void updateLift(Lift lift) {
    em.merge(lift);
   
    }

    @Override
    public void deleteLift(Integer id) {
    em.remove(em.find(Lift.class, id));
    
    }
    
    @Override
    public List getLifts(){
        Query query = em.createNamedQuery("Lift.findAll").setMaxResults(100);
        return query.getResultList();
        
    }
    
    @Override
    public Lift getLiftById(Integer in){
        return em.find(Lift.class, in);
        
    }
    
    @Override
    public List getLiftByNumber(Integer Id){
        Query query = em.createNamedQuery("Lift.findByLiftNumber").setMaxResults(100);
        query.setParameter("liftNumber", Id);
        return query.getResultList();
        
        
 }
    
    @Override
    public List getLiftByMine(String minename){
        Query query = em.createNamedQuery("Lift.findByMineName").setMaxResults(100);
        query.setParameter("mineName", minename);
        return query.getResultList();
    
    }
    
    @Override
    public List getLiftByStatus(String status){
        Query query = em.createNamedQuery("Lift.findByLiftStatus").setMaxResults(100);
        query.setParameter("liftStatus", status);
        return query.getResultList();
        
    }
    
    
   
    
    
    
    
    
    
}



