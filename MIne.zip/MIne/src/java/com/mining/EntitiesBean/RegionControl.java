/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Region;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author ERavhengani
 */
@Stateless
public class RegionControl implements RegionControlLocal {

    @PersistenceContext
    EntityManager em;
    
    @Override
    public void addRegion(Region region) {
        em.persist(region);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public void deleteRegion(Region region) {
        em.remove(region);
    }

    @Override
    public void updateRegion(Region region) {
        em.merge(region);
    }

    @Override
    public List<Region> getRegions() {
        return em.createNamedQuery("Region.findAll").setMaxResults(100).getResultList();
    }

    @Override
    public Region getRegionByName(String region) {
        return em.find(Region.class, region);
    }
    
    
    
    
}
