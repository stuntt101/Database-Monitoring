/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Shaft;
import com.mining.annotations.ElphyAnotation;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author ERavhengani
 */
@Stateless
public class ShaftControl implements ShaftControlLocal {

    @PersistenceContext
    private EntityManager em;

    @Override
    public void addShaft(Shaft shaft) {
        em.persist(shaft);
    }

    @Override
    public void updateShaft(Shaft shaft) {
        em.merge(shaft);
    }

    @Override
    public void deleteShaft(Integer id) {
        em.remove(em.find(Shaft.class, id));
    }

    @Override
    public List getShafts() {
       Query query =  em.createNamedQuery("Shaft.findAll").setMaxResults(100);
       return query.getResultList();  
    }

    
    public Shaft getShaftById(Integer in){
       return em.find(Shaft.class, in);
    }
    
    @Override
    public List getShaftByNumber(Integer Id) {
       Query query =  em.createNamedQuery("Shaft.findByShaftNumber").setMaxResults(100);
       query.setParameter("shaftNumber", Id);
        return query.getResultList();  
    }

    @Override
    public List getShaftByName(String name) {//
       Query query =  em.createNamedQuery("Shaft.findByShaftName").setMaxResults(100);
       query.setParameter("shaftName", name);
        return query.getResultList();
    }


    @Override
    public List getShaftByMine(String minename) {
       Query query =  em.createNamedQuery("Shaft.findByMineName").setMaxResults(100);
       query.setParameter("mineName", minename);
        return query.getResultList();            
    }
    

    
    
    
}
