/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Shaft;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ERavhengani
 */
@Local
public interface ShaftControlLocal {

    void addShaft(Shaft shaft);

    void updateShaft(Shaft shaft);

    void deleteShaft(Integer id);

    List getShafts();

    List getShaftByNumber(Integer Id);

    List getShaftByName(String name);

    List getShaftByMine(String minename);

    public Shaft getShaftById(Integer in);



  
    
}
