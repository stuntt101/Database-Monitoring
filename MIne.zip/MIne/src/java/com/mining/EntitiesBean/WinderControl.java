/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Winder;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author ERavhengani
 */
@Stateless
public class WinderControl implements WinderControlLocal {

    @PersistenceContext
    private EntityManager em;

    @Override
    public void addWinder(Winder winder) {
        em.persist(winder);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public void updateWinder(Winder winder) {
        em.merge(winder);

    }

    @Override
    public void deleteWinder(Integer id) {
        em.remove(em.find(Winder.class, id));
    }


    @Override
    public List getWinders() {
       Query query =  em.createNamedQuery("Winder.findAll").setMaxResults(100);
       return query.getResultList();  
    }
    

 
    public Winder getWinderById(Integer in)
    {
    return em.find(Winder.class, in);
    }
    

    @Override
    public List getWinderByNumber(Integer Id) {
       Query query =  em.createNamedQuery("Winder.findByWinderNumber").setMaxResults(100);
       query.setParameter("winderNumber", Id);
        return query.getResultList();  
    }
        @Override
    public List getWinderByShaft(String name) {//
       Query query =  em.createNamedQuery("Winder.findByShaftName").setMaxResults(100);
       query.setParameter("shaftName", name);
        return query.getResultList();
    }
    
    	   @Override
    public List getWinderByMine(String minename) {
       Query query =  em.createNamedQuery("Winder.findByMineName").setMaxResults(100);
       query.setParameter("mineName", minename);
        return query.getResultList();            
    }
    
        public List getWinderByStatus(String status) {//
       Query query =  em.createNamedQuery("Winder.findByWinderStatus").setMaxResults(100);
       query.setParameter("winderStatus", status);
        return query.getResultList();
        }

}
