/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.EntitiesBean;

import com.mining.Entities.Mine;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author ERavhengani
 */
@Stateless
public class MineControl implements MineControlLocal {

    @PersistenceContext
    EntityManager em;

            
    @Override
    public void updateMine(Mine mine) {
        em.merge(mine);
    }


    @Override
    public void deleteMine(Mine mine) {
        em.remove(mine);
    }

    @Override
    public void addMine(Mine mine) {
        em.persist(mine);
    }

    @Override
    public Mine getMineById(Integer mine_id) {
        return em.find(Mine.class, mine_id);
    }

    @Override
    public List getAllMine() {
        return em.createNamedQuery("Mine.findAll").setMaxResults(100).getResultList();
    }

    @Override
    public Mine getMineByName(String mine) {
        return (Mine)em.createNamedQuery("Mine.findByMineName").setParameter("mineName", mine).getResultList().get(0);
    }


    
    
    
    
}
