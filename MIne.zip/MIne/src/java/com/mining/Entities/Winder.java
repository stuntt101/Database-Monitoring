/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.Entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ERavhengani
 */
@Entity
@Table(name = "winder")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Winder.findAll", query = "SELECT w FROM Winder w"),
    @NamedQuery(name = "Winder.findByWinderNumber", query = "SELECT w FROM Winder w WHERE w.winderNumber = :winderNumber"),
    @NamedQuery(name = "Winder.findByMineName", query = "SELECT w FROM Winder w WHERE w.mineName = :mineName"),
    @NamedQuery(name = "Winder.findByPreviousRegion", query = "SELECT w FROM Winder w WHERE w.previousRegion = :previousRegion"),
    @NamedQuery(name = "Winder.findByNewWinder", query = "SELECT w FROM Winder w WHERE w.newWinder = :newWinder"),
    @NamedQuery(name = "Winder.findByPreviousNumber", query = "SELECT w FROM Winder w WHERE w.previousNumber = :previousNumber"),
    @NamedQuery(name = "Winder.findByDateOfApplication", query = "SELECT w FROM Winder w WHERE w.dateOfApplication = :dateOfApplication"),
    @NamedQuery(name = "Winder.findByWinderType", query = "SELECT w FROM Winder w WHERE w.winderType = :winderType"),
    @NamedQuery(name = "Winder.findByShaftName", query = "SELECT w FROM Winder w WHERE w.shaftName = :shaftName"),
    @NamedQuery(name = "Winder.findByWinderStatus", query = "SELECT w FROM Winder w WHERE w.winderStatus = :winderStatus"),
    @NamedQuery(name = "Winder.findByWinderClass", query = "SELECT w FROM Winder w WHERE w.winderClass = :winderClass"),
    @NamedQuery(name = "Winder.findByDatePermitIssued", query = "SELECT w FROM Winder w WHERE w.datePermitIssued = :datePermitIssued"),
    @NamedQuery(name = "Winder.findByTopClearance", query = "SELECT w FROM Winder w WHERE w.topClearance = :topClearance"),
    @NamedQuery(name = "Winder.findByBottomClearance", query = "SELECT w FROM Winder w WHERE w.bottomClearance = :bottomClearance"),
    @NamedQuery(name = "Winder.findBySheaveDiameter", query = "SELECT w FROM Winder w WHERE w.sheaveDiameter = :sheaveDiameter"),
    @NamedQuery(name = "Winder.findBySheaveOrRopeRatio", query = "SELECT w FROM Winder w WHERE w.sheaveOrRopeRatio = :sheaveOrRopeRatio"),
    @NamedQuery(name = "Winder.findByMaxNoOfPersons", query = "SELECT w FROM Winder w WHERE w.maxNoOfPersons = :maxNoOfPersons"),
    @NamedQuery(name = "Winder.findByMaxMassMaterial", query = "SELECT w FROM Winder w WHERE w.maxMassMaterial = :maxMassMaterial"),
    @NamedQuery(name = "Winder.findByMaxMassMineral", query = "SELECT w FROM Winder w WHERE w.maxMassMineral = :maxMassMineral"),
    @NamedQuery(name = "Winder.findByDepthIndicateType", query = "SELECT w FROM Winder w WHERE w.depthIndicateType = :depthIndicateType"),
    @NamedQuery(name = "Winder.findByManufacturer", query = "SELECT w FROM Winder w WHERE w.manufacturer = :manufacturer"),
    @NamedQuery(name = "Winder.findByYearManufactured", query = "SELECT w FROM Winder w WHERE w.yearManufactured = :yearManufactured"),
    @NamedQuery(name = "Winder.findByNumberOfMotorsUsed", query = "SELECT w FROM Winder w WHERE w.numberOfMotorsUsed = :numberOfMotorsUsed"),
    @NamedQuery(name = "Winder.findByPrimeMover", query = "SELECT w FROM Winder w WHERE w.primeMover = :primeMover"),
    @NamedQuery(name = "Winder.findByPowerRating", query = "SELECT w FROM Winder w WHERE w.powerRating = :powerRating"),
    @NamedQuery(name = "Winder.findByRpm", query = "SELECT w FROM Winder w WHERE w.rpm = :rpm"),
    @NamedQuery(name = "Winder.findBySupplyVoltage", query = "SELECT w FROM Winder w WHERE w.supplyVoltage = :supplyVoltage"),
    @NamedQuery(name = "Winder.findByMgSet", query = "SELECT w FROM Winder w WHERE w.mgSet = :mgSet")})
public class Winder implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "winder_number")
    private Integer winderNumber;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "mine_name")
    private String mineName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "previous_region")
    private String previousRegion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "new_winder")
    private String newWinder;
    @Basic(optional = false)
    @NotNull
    @Column(name = "previous_number")
    private int previousNumber;
    @Basic(optional = false)
    @NotNull
    @Column(name = "date_of_application")
    @Temporal(TemporalType.DATE)
    private Date dateOfApplication;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "winder_type")
    private String winderType;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "shaft_name")
    private String shaftName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "winder_status")
    private String winderStatus;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "winder_class")
    private String winderClass;
    @Basic(optional = false)
    @NotNull
    @Column(name = "date_permit_issued")
    @Temporal(TemporalType.DATE)
    private Date datePermitIssued;
    @Basic(optional = false)
    @NotNull
    @Column(name = "top_clearance")
    private int topClearance;
    @Basic(optional = false)
    @NotNull
    @Column(name = "bottom_clearance")
    private int bottomClearance;
    @Basic(optional = false)
    @NotNull
    @Column(name = "sheave_diameter")
    private float sheaveDiameter;
    @Basic(optional = false)
    @NotNull
    @Column(name = "sheave_or_rope_ratio")
    private float sheaveOrRopeRatio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "max_no_of_persons")
    private int maxNoOfPersons;
    @Basic(optional = false)
    @NotNull
    @Column(name = "max_mass_material")
    private float maxMassMaterial;
    @Basic(optional = false)
    @NotNull
    @Column(name = "max_mass_mineral")
    private float maxMassMineral;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "depth_indicate_type")
    private String depthIndicateType;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "manufacturer")
    private String manufacturer;
    @Basic(optional = false)
    @NotNull
    @Column(name = "year_manufactured")
    private int yearManufactured;
    @Basic(optional = false)
    @NotNull
    @Column(name = "number_of_motors_used")
    private int numberOfMotorsUsed;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "prime_mover")
    private String primeMover;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "power_rating")
    private String powerRating;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "rpm")
    private String rpm;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "supply_voltage")
    private String supplyVoltage;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "mg_set")
    private String mgSet;
    @JoinColumn(name = "mine_number", referencedColumnName = "mine_number")
    @ManyToOne(optional = false)
    private Mine mineNumber;
    @JoinColumn(name = "region_name", referencedColumnName = "region_name")
    @ManyToOne(optional = false)
    private Region regionName;
    @JoinColumn(name = "shaft_number", referencedColumnName = "shaft_number")
    @ManyToOne(optional = false)
    private Shaft shaftNumber;

    public Winder() {
    }

    public Winder(Integer winderNumber) {
        this.winderNumber = winderNumber;
    }

    public Winder(Integer winderNumber, String mineName, String previousRegion, String newWinder, int previousNumber, Date dateOfApplication, String winderType, String shaftName, String winderStatus, String winderClass, Date datePermitIssued, int topClearance, int bottomClearance, float sheaveDiameter, float sheaveOrRopeRatio, int maxNoOfPersons, float maxMassMaterial, float maxMassMineral, String depthIndicateType, String manufacturer, int yearManufactured, int numberOfMotorsUsed, String primeMover, String powerRating, String rpm, String supplyVoltage, String mgSet) {
        this.winderNumber = winderNumber;
        this.mineName = mineName;
        this.previousRegion = previousRegion;
        this.newWinder = newWinder;
        this.previousNumber = previousNumber;
        this.dateOfApplication = dateOfApplication;
        this.winderType = winderType;
        this.shaftName = shaftName;
        this.winderStatus = winderStatus;
        this.winderClass = winderClass;
        this.datePermitIssued = datePermitIssued;
        this.topClearance = topClearance;
        this.bottomClearance = bottomClearance;
        this.sheaveDiameter = sheaveDiameter;
        this.sheaveOrRopeRatio = sheaveOrRopeRatio;
        this.maxNoOfPersons = maxNoOfPersons;
        this.maxMassMaterial = maxMassMaterial;
        this.maxMassMineral = maxMassMineral;
        this.depthIndicateType = depthIndicateType;
        this.manufacturer = manufacturer;
        this.yearManufactured = yearManufactured;
        this.numberOfMotorsUsed = numberOfMotorsUsed;
        this.primeMover = primeMover;
        this.powerRating = powerRating;
        this.rpm = rpm;
        this.supplyVoltage = supplyVoltage;
        this.mgSet = mgSet;
    }

    public Integer getWinderNumber() {
        return winderNumber;
    }

    public void setWinderNumber(Integer winderNumber) {
        this.winderNumber = winderNumber;
    }

    public String getMineName() {
        return mineName;
    }

    public void setMineName(String mineName) {
        this.mineName = mineName;
    }

    public String getPreviousRegion() {
        return previousRegion;
    }

    public void setPreviousRegion(String previousRegion) {
        this.previousRegion = previousRegion;
    }

    public String getNewWinder() {
        return newWinder;
    }

    public void setNewWinder(String newWinder) {
        this.newWinder = newWinder;
    }

    public int getPreviousNumber() {
        return previousNumber;
    }

    public void setPreviousNumber(int previousNumber) {
        this.previousNumber = previousNumber;
    }

    public Date getDateOfApplication() {
        return dateOfApplication;
    }

    public void setDateOfApplication(Date dateOfApplication) {
        this.dateOfApplication = dateOfApplication;
    }

    public String getWinderType() {
        return winderType;
    }

    public void setWinderType(String winderType) {
        this.winderType = winderType;
    }

    public String getShaftName() {
        return shaftName;
    }

    public void setShaftName(String shaftName) {
        this.shaftName = shaftName;
    }

    public String getWinderStatus() {
        return winderStatus;
    }

    public void setWinderStatus(String winderStatus) {
        this.winderStatus = winderStatus;
    }

    public String getWinderClass() {
        return winderClass;
    }

    public void setWinderClass(String winderClass) {
        this.winderClass = winderClass;
    }

    public Date getDatePermitIssued() {
        return datePermitIssued;
    }

    public void setDatePermitIssued(Date datePermitIssued) {
        this.datePermitIssued = datePermitIssued;
    }

    public int getTopClearance() {
        return topClearance;
    }

    public void setTopClearance(int topClearance) {
        this.topClearance = topClearance;
    }

    public int getBottomClearance() {
        return bottomClearance;
    }

    public void setBottomClearance(int bottomClearance) {
        this.bottomClearance = bottomClearance;
    }

    public float getSheaveDiameter() {
        return sheaveDiameter;
    }

    public void setSheaveDiameter(float sheaveDiameter) {
        this.sheaveDiameter = sheaveDiameter;
    }

    public float getSheaveOrRopeRatio() {
        return sheaveOrRopeRatio;
    }

    public void setSheaveOrRopeRatio(float sheaveOrRopeRatio) {
        this.sheaveOrRopeRatio = sheaveOrRopeRatio;
    }

    public int getMaxNoOfPersons() {
        return maxNoOfPersons;
    }

    public void setMaxNoOfPersons(int maxNoOfPersons) {
        this.maxNoOfPersons = maxNoOfPersons;
    }

    public float getMaxMassMaterial() {
        return maxMassMaterial;
    }

    public void setMaxMassMaterial(float maxMassMaterial) {
        this.maxMassMaterial = maxMassMaterial;
    }

    public float getMaxMassMineral() {
        return maxMassMineral;
    }

    public void setMaxMassMineral(float maxMassMineral) {
        this.maxMassMineral = maxMassMineral;
    }

    public String getDepthIndicateType() {
        return depthIndicateType;
    }

    public void setDepthIndicateType(String depthIndicateType) {
        this.depthIndicateType = depthIndicateType;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public int getYearManufactured() {
        return yearManufactured;
    }

    public void setYearManufactured(int yearManufactured) {
        this.yearManufactured = yearManufactured;
    }

    public int getNumberOfMotorsUsed() {
        return numberOfMotorsUsed;
    }

    public void setNumberOfMotorsUsed(int numberOfMotorsUsed) {
        this.numberOfMotorsUsed = numberOfMotorsUsed;
    }

    public String getPrimeMover() {
        return primeMover;
    }

    public void setPrimeMover(String primeMover) {
        this.primeMover = primeMover;
    }

    public String getPowerRating() {
        return powerRating;
    }

    public void setPowerRating(String powerRating) {
        this.powerRating = powerRating;
    }

    public String getRpm() {
        return rpm;
    }

    public void setRpm(String rpm) {
        this.rpm = rpm;
    }

    public String getSupplyVoltage() {
        return supplyVoltage;
    }

    public void setSupplyVoltage(String supplyVoltage) {
        this.supplyVoltage = supplyVoltage;
    }

    public String getMgSet() {
        return mgSet;
    }

    public void setMgSet(String mgSet) {
        this.mgSet = mgSet;
    }

    public Mine getMineNumber() {
        return mineNumber;
    }

    public void setMineNumber(Mine mineNumber) {
        this.mineNumber = mineNumber;
    }

    public Region getRegionName() {
        return regionName;
    }

    public void setRegionName(Region regionName) {
        this.regionName = regionName;
    }

    public Shaft getShaftNumber() {
        return shaftNumber;
    }

    public void setShaftNumber(Shaft shaftNumber) {
        this.shaftNumber = shaftNumber;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (winderNumber != null ? winderNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Winder)) {
            return false;
        }
        Winder other = (Winder) object;
        if ((this.winderNumber == null && other.winderNumber != null) || (this.winderNumber != null && !this.winderNumber.equals(other.winderNumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mining.Entities.Winder[ winderNumber=" + winderNumber + " ]";
    }
    
}
