/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.Entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ERavhengani
 */
@Entity
@Table(name = "boiler")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Boiler.findAll", query = "SELECT b FROM Boiler b"),
    @NamedQuery(name = "Boiler.findByBoilerNumber", query = "SELECT b FROM Boiler b WHERE b.boilerNumber = :boilerNumber"),
    @NamedQuery(name = "Boiler.findByMineName", query = "SELECT b FROM Boiler b WHERE b.mineName = :mineName"),
    @NamedQuery(name = "Boiler.findByNewBoiler", query = "SELECT b FROM Boiler b WHERE b.newBoiler = :newBoiler"),
    @NamedQuery(name = "Boiler.findByPreviousRegion", query = "SELECT b FROM Boiler b WHERE b.previousRegion = :previousRegion"),
    @NamedQuery(name = "Boiler.findByLocation", query = "SELECT b FROM Boiler b WHERE b.location = :location"),
    @NamedQuery(name = "Boiler.findByTypeOfBoiler", query = "SELECT b FROM Boiler b WHERE b.typeOfBoiler = :typeOfBoiler"),
    @NamedQuery(name = "Boiler.findByManufacturer", query = "SELECT b FROM Boiler b WHERE b.manufacturer = :manufacturer"),
    @NamedQuery(name = "Boiler.findByCountryOfOrigion", query = "SELECT b FROM Boiler b WHERE b.countryOfOrigion = :countryOfOrigion"),
    @NamedQuery(name = "Boiler.findBySerialNumber", query = "SELECT b FROM Boiler b WHERE b.serialNumber = :serialNumber"),
    @NamedQuery(name = "Boiler.findByYearManufactured", query = "SELECT b FROM Boiler b WHERE b.yearManufactured = :yearManufactured"),
    @NamedQuery(name = "Boiler.findByYearInstalled", query = "SELECT b FROM Boiler b WHERE b.yearInstalled = :yearInstalled"),
    @NamedQuery(name = "Boiler.findByMaxAuthorizedWorkingPressure", query = "SELECT b FROM Boiler b WHERE b.maxAuthorizedWorkingPressure = :maxAuthorizedWorkingPressure"),
    @NamedQuery(name = "Boiler.findByEvaporativeCapacity", query = "SELECT b FROM Boiler b WHERE b.evaporativeCapacity = :evaporativeCapacity"),
    @NamedQuery(name = "Boiler.findBySourceOfHeat", query = "SELECT b FROM Boiler b WHERE b.sourceOfHeat = :sourceOfHeat"),
    @NamedQuery(name = "Boiler.findByBoilerStatus", query = "SELECT b FROM Boiler b WHERE b.boilerStatus = :boilerStatus")})
public class Boiler implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "boiler_number")
    private Integer boilerNumber;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "mine_name")
    private String mineName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "new_boiler")
    private String newBoiler;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "previous_region")
    private String previousRegion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "location")
    private String location;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "type_of_boiler")
    private String typeOfBoiler;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "manufacturer")
    private String manufacturer;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "country_of_origion")
    private String countryOfOrigion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "serial_number")
    private String serialNumber;
    @Basic(optional = false)
    @NotNull
    @Column(name = "year_manufactured")
    private int yearManufactured;
    @Basic(optional = false)
    @NotNull
    @Column(name = "year_installed")
    private int yearInstalled;
    @Basic(optional = false)
    @NotNull
    @Column(name = "max_authorized_working_pressure")
    private float maxAuthorizedWorkingPressure;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "evaporative_capacity")
    private String evaporativeCapacity;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "source_of_heat")
    private String sourceOfHeat;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "boiler_status")
    private String boilerStatus;
    @JoinColumn(name = "mine_number", referencedColumnName = "mine_number")
    @ManyToOne(optional = false)
    private Mine mineNumber;
    @JoinColumn(name = "region_name", referencedColumnName = "region_name")
    @ManyToOne(optional = false)
    private Region regionName;

    public Boiler() {
    }

    public Boiler(Integer boilerNumber) {
        this.boilerNumber = boilerNumber;
    }

    public Boiler(Integer boilerNumber, String mineName, String newBoiler, String previousRegion, String location, String typeOfBoiler, String manufacturer, String countryOfOrigion, String serialNumber, int yearManufactured, int yearInstalled, float maxAuthorizedWorkingPressure, String evaporativeCapacity, String sourceOfHeat, String boilerStatus) {
        this.boilerNumber = boilerNumber;
        this.mineName = mineName;
        this.newBoiler = newBoiler;
        this.previousRegion = previousRegion;
        this.location = location;
        this.typeOfBoiler = typeOfBoiler;
        this.manufacturer = manufacturer;
        this.countryOfOrigion = countryOfOrigion;
        this.serialNumber = serialNumber;
        this.yearManufactured = yearManufactured;
        this.yearInstalled = yearInstalled;
        this.maxAuthorizedWorkingPressure = maxAuthorizedWorkingPressure;
        this.evaporativeCapacity = evaporativeCapacity;
        this.sourceOfHeat = sourceOfHeat;
        this.boilerStatus = boilerStatus;
    }

    public Integer getBoilerNumber() {
        return boilerNumber;
    }

    public void setBoilerNumber(Integer boilerNumber) {
        this.boilerNumber = boilerNumber;
    }

    public String getMineName() {
        return mineName;
    }

    public void setMineName(String mineName) {
        this.mineName = mineName;
    }

    public String getNewBoiler() {
        return newBoiler;
    }

    public void setNewBoiler(String newBoiler) {
        this.newBoiler = newBoiler;
    }

    public String getPreviousRegion() {
        return previousRegion;
    }

    public void setPreviousRegion(String previousRegion) {
        this.previousRegion = previousRegion;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTypeOfBoiler() {
        return typeOfBoiler;
    }

    public void setTypeOfBoiler(String typeOfBoiler) {
        this.typeOfBoiler = typeOfBoiler;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getCountryOfOrigion() {
        return countryOfOrigion;
    }

    public void setCountryOfOrigion(String countryOfOrigion) {
        this.countryOfOrigion = countryOfOrigion;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public int getYearManufactured() {
        return yearManufactured;
    }

    public void setYearManufactured(int yearManufactured) {
        this.yearManufactured = yearManufactured;
    }

    public int getYearInstalled() {
        return yearInstalled;
    }

    public void setYearInstalled(int yearInstalled) {
        this.yearInstalled = yearInstalled;
    }

    public float getMaxAuthorizedWorkingPressure() {
        return maxAuthorizedWorkingPressure;
    }

    public void setMaxAuthorizedWorkingPressure(float maxAuthorizedWorkingPressure) {
        this.maxAuthorizedWorkingPressure = maxAuthorizedWorkingPressure;
    }

    public String getEvaporativeCapacity() {
        return evaporativeCapacity;
    }

    public void setEvaporativeCapacity(String evaporativeCapacity) {
        this.evaporativeCapacity = evaporativeCapacity;
    }

    public String getSourceOfHeat() {
        return sourceOfHeat;
    }

    public void setSourceOfHeat(String sourceOfHeat) {
        this.sourceOfHeat = sourceOfHeat;
    }

    public String getBoilerStatus() {
        return boilerStatus;
    }

    public void setBoilerStatus(String boilerStatus) {
        this.boilerStatus = boilerStatus;
    }

    public Mine getMineNumber() {
        return mineNumber;
    }

    public void setMineNumber(Mine mineNumber) {
        this.mineNumber = mineNumber;
    }

    public Region getRegionName() {
        return regionName;
    }

    public void setRegionName(Region regionName) {
        this.regionName = regionName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (boilerNumber != null ? boilerNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Boiler)) {
            return false;
        }
        Boiler other = (Boiler) object;
        if ((this.boilerNumber == null && other.boilerNumber != null) || (this.boilerNumber != null && !this.boilerNumber.equals(other.boilerNumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mining.Entities.Boiler[ boilerNumber=" + boilerNumber + " ]";
    }
    
}
