/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.Entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ERavhengani
 */
@Entity
@Table(name = "region")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Region.findAll", query = "SELECT r FROM Region r"),
    @NamedQuery(name = "Region.findByRegionName", query = "SELECT r FROM Region r WHERE r.regionName = :regionName")})
public class Region implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "region_name")
    private String regionName;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private List<Mine> mineList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private List<Chairlift> chairliftList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private List<Manager> managerList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private List<Boiler> boilerList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private List<Lift> liftList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private List<Inspector> inspectorList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private List<Winder> winderList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private List<Shaft> shaftList;

    public Region() {
    }

    public Region(String regionName) {
        this.regionName = regionName;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    @XmlTransient
    public List<Mine> getMineList() {
        return mineList;
    }

    public void setMineList(List<Mine> mineList) {
        this.mineList = mineList;
    }

    @XmlTransient
    public List<Chairlift> getChairliftList() {
        return chairliftList;
    }

    public void setChairliftList(List<Chairlift> chairliftList) {
        this.chairliftList = chairliftList;
    }

    @XmlTransient
    public List<Manager> getManagerList() {
        return managerList;
    }

    public void setManagerList(List<Manager> managerList) {
        this.managerList = managerList;
    }

    @XmlTransient
    public List<Boiler> getBoilerList() {
        return boilerList;
    }

    public void setBoilerList(List<Boiler> boilerList) {
        this.boilerList = boilerList;
    }

    @XmlTransient
    public List<Lift> getLiftList() {
        return liftList;
    }

    public void setLiftList(List<Lift> liftList) {
        this.liftList = liftList;
    }

    @XmlTransient
    public List<Inspector> getInspectorList() {
        return inspectorList;
    }

    public void setInspectorList(List<Inspector> inspectorList) {
        this.inspectorList = inspectorList;
    }

    @XmlTransient
    public List<Winder> getWinderList() {
        return winderList;
    }

    public void setWinderList(List<Winder> winderList) {
        this.winderList = winderList;
    }

    @XmlTransient
    public List<Shaft> getShaftList() {
        return shaftList;
    }

    public void setShaftList(List<Shaft> shaftList) {
        this.shaftList = shaftList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (regionName != null ? regionName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Region)) {
            return false;
        }
        Region other = (Region) object;
        if ((this.regionName == null && other.regionName != null) || (this.regionName != null && !this.regionName.equals(other.regionName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return regionName;
    }
    
}
