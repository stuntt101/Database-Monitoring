/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.Entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ERavhengani
 */
@Entity
@Table(name = "shaft")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Shaft.findAll", query = "SELECT s FROM Shaft s"),
    @NamedQuery(name = "Shaft.findByShaftNumber", query = "SELECT s FROM Shaft s WHERE s.shaftNumber = :shaftNumber"),
    @NamedQuery(name = "Shaft.findByShaftName", query = "SELECT s FROM Shaft s WHERE s.shaftName = :shaftName"),
    @NamedQuery(name = "Shaft.findByMineName", query = "SELECT s FROM Shaft s WHERE s.mineName = :mineName"),
    @NamedQuery(name = "Shaft.findByNewShaft", query = "SELECT s FROM Shaft s WHERE s.newShaft = :newShaft"),
    @NamedQuery(name = "Shaft.findByShaftStatus", query = "SELECT s FROM Shaft s WHERE s.shaftStatus = :shaftStatus"),
    @NamedQuery(name = "Shaft.findByShaftShape", query = "SELECT s FROM Shaft s WHERE s.shaftShape = :shaftShape"),
    @NamedQuery(name = "Shaft.findByShaftDimensions", query = "SELECT s FROM Shaft s WHERE s.shaftDimensions = :shaftDimensions"),
    @NamedQuery(name = "Shaft.findByVentilationFlow", query = "SELECT s FROM Shaft s WHERE s.ventilationFlow = :ventilationFlow"),
    @NamedQuery(name = "Shaft.findByShaftCondition", query = "SELECT s FROM Shaft s WHERE s.shaftCondition = :shaftCondition"),
    @NamedQuery(name = "Shaft.findByWaterCondition", query = "SELECT s FROM Shaft s WHERE s.waterCondition = :waterCondition"),
    @NamedQuery(name = "Shaft.findByAvgPersonTransportedPerDay", query = "SELECT s FROM Shaft s WHERE s.avgPersonTransportedPerDay = :avgPersonTransportedPerDay"),
    @NamedQuery(name = "Shaft.findByVerticalShaftDepth", query = "SELECT s FROM Shaft s WHERE s.verticalShaftDepth = :verticalShaftDepth"),
    @NamedQuery(name = "Shaft.findByInclinationLength", query = "SELECT s FROM Shaft s WHERE s.inclinationLength = :inclinationLength"),
    @NamedQuery(name = "Shaft.findByInclinationAngle", query = "SELECT s FROM Shaft s WHERE s.inclinationAngle = :inclinationAngle"),
    @NamedQuery(name = "Shaft.findByNumberOfRopes", query = "SELECT s FROM Shaft s WHERE s.numberOfRopes = :numberOfRopes")
})
public class Shaft implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "shaft_number")
    private Integer shaftNumber;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "shaft_name")
    private String shaftName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "mine_name")
    private String mineName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "new_shaft")
    private String newShaft;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "shaft_status")
    private String shaftStatus;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "shaft_shape")
    private String shaftShape;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "shaft_dimensions")
    private String shaftDimensions;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "ventilation_flow")
    private String ventilationFlow;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "shaft_condition")
    private String shaftCondition;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "water_condition")
    private String waterCondition;
    @Basic(optional = false)
    @NotNull
    @Column(name = "avg_person_transported_per_day")
    private float avgPersonTransportedPerDay;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "vertical_shaft_depth")
    private String verticalShaftDepth;
    @Basic(optional = false)
    @NotNull
    @Column(name = "inclination_length")
    private float inclinationLength;
    @Basic(optional = false)
    @NotNull
    @Column(name = "inclination_angle")
    private float inclinationAngle;
    @Basic(optional = false)
    @NotNull
    @Column(name = "number_of_ropes")
    private int numberOfRopes;
     
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "shaftNumber")
    private List<Chairlift> chairliftList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "shaftNumber")
    private List<Lift> liftList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "shaftNumber")
    private List<Winder> winderList;
    @JoinColumn(name = "mine_number", referencedColumnName = "mine_number")
    @ManyToOne(optional = false)
    private Mine mineNumber;
    @JoinColumn(name = "region_name", referencedColumnName = "region_name")
    @ManyToOne(optional = false)
    private Region regionName;

    public Shaft() {
    }

    public Shaft(Integer shaftNumber) {
        this.shaftNumber = shaftNumber;
    }

    public Shaft(Integer shaftNumber, String shaftName, String mineName, String newShaft, String shaftStatus, String shaftShape, String shaftDimensions, String ventilationFlow, String shaftCondition, String waterCondition, float avgPersonTransportedPerDay, String verticalShaftDepth, float inclinationLength, float inclinationAngle, int numberOfRopes) {
        this.shaftNumber = shaftNumber;
        this.shaftName = shaftName;
        this.mineName = mineName;
        this.newShaft = newShaft;
        this.shaftStatus = shaftStatus;
        this.shaftShape = shaftShape;
        this.shaftDimensions = shaftDimensions;
        this.ventilationFlow = ventilationFlow;
        this.shaftCondition = shaftCondition;
        this.waterCondition = waterCondition;
        this.avgPersonTransportedPerDay = avgPersonTransportedPerDay;
        this.verticalShaftDepth = verticalShaftDepth;
        this.inclinationLength = inclinationLength;
        this.inclinationAngle = inclinationAngle;
        this.numberOfRopes = numberOfRopes;
      
    }

    public Integer getShaftNumber() {
        return shaftNumber;
    }

    public void setShaftNumber(Integer shaftNumber) {
        this.shaftNumber = shaftNumber;
    }

    public String getShaftName() {
        return shaftName;
    }

    public void setShaftName(String shaftName) {
        this.shaftName = shaftName;
    }

    public String getMineName() {
        return mineName;
    }

    public void setMineName(String mineName) {
        this.mineName = mineName;
    }

    public String getNewShaft() {
        return newShaft;
    }

    public void setNewShaft(String newShaft) {
        this.newShaft = newShaft;
    }

    public String getShaftStatus() {
        return shaftStatus;
    }

    public void setShaftStatus(String shaftStatus) {
        this.shaftStatus = shaftStatus;
    }

    public String getShaftShape() {
        return shaftShape;
    }

    public void setShaftShape(String shaftShape) {
        this.shaftShape = shaftShape;
    }

    public String getShaftDimensions() {
        return shaftDimensions;
    }

    public void setShaftDimensions(String shaftDimensions) {
        this.shaftDimensions = shaftDimensions;
    }

    public String getVentilationFlow() {
        return ventilationFlow;
    }

    public void setVentilationFlow(String ventilationFlow) {
        this.ventilationFlow = ventilationFlow;
    }

    public String getShaftCondition() {
        return shaftCondition;
    }

    public void setShaftCondition(String shaftCondition) {
        this.shaftCondition = shaftCondition;
    }

    public String getWaterCondition() {
        return waterCondition;
    }

    public void setWaterCondition(String waterCondition) {
        this.waterCondition = waterCondition;
    }

    public float getAvgPersonTransportedPerDay() {
        return avgPersonTransportedPerDay;
    }

    public void setAvgPersonTransportedPerDay(float avgPersonTransportedPerDay) {
        this.avgPersonTransportedPerDay = avgPersonTransportedPerDay;
    }

    public String getVerticalShaftDepth() {
        return verticalShaftDepth;
    }

    public void setVerticalShaftDepth(String verticalShaftDepth) {
        this.verticalShaftDepth = verticalShaftDepth;
    }

    public float getInclinationLength() {
        return inclinationLength;
    }

    public void setInclinationLength(float inclinationLength) {
        this.inclinationLength = inclinationLength;
    }

    public float getInclinationAngle() {
        return inclinationAngle;
    }

    public void setInclinationAngle(float inclinationAngle) {
        this.inclinationAngle = inclinationAngle;
    }

    public int getNumberOfRopes() {
        return numberOfRopes;
    }

    public void setNumberOfRopes(int numberOfRopes) {
        this.numberOfRopes = numberOfRopes;
    }

    @XmlTransient
    public List<Chairlift> getChairliftList() {
        return chairliftList;
    }

    public void setChairliftList(List<Chairlift> chairliftList) {
        this.chairliftList = chairliftList;
    }

    @XmlTransient
    public List<Lift> getLiftList() {
        return liftList;
    }

    public void setLiftList(List<Lift> liftList) {
        this.liftList = liftList;
    }

    @XmlTransient
    public List<Winder> getWinderList() {
        return winderList;
    }

    public void setWinderList(List<Winder> winderList) {
        this.winderList = winderList;
    }

    public Mine getMineNumber() {
        return mineNumber;
    }

    public void setMineNumber(Mine mineNumber) {
        this.mineNumber = mineNumber;
    }

    public Region getRegionName() {
        return regionName;
    }

    public void setRegionName(Region regionName) {
        this.regionName = regionName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (shaftNumber != null ? shaftNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Shaft)) {
            return false;
        }
        Shaft other = (Shaft) object;
        if ((this.shaftNumber == null && other.shaftNumber != null) || (this.shaftNumber != null && !this.shaftNumber.equals(other.shaftNumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mining.Entities.Shaft[ shaftNumber=" + shaftNumber + " ]";
    }
    
}
