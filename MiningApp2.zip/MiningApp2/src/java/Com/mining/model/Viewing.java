/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Com.mining.model;

/**
 *
 * @author ERavhengani
 */
public class Viewing {
 
    
    private int shaft_number;
    private String shaft_name;
    private int mine_number;

 private String mine_name, region_name, new_shaft, shaft_status, shaft_shape, shaft_dimensions, ventilation_flow;
 private String shaft_condition, water_condition;
 private float avg_person_transported_per_day;  
 private String vertical_shaft_depth;
 private float inclination_length, inclination_angle;
 private int  number_of_ropes;

    public Viewing(int shaft_number, String shaft_name, int mine_number, String mine_name, String region_name, String new_shaft, String shaft_status, String shaft_shape, String shaft_dimensions, String ventilation_flow, String shaft_condition, String water_condition, float avg_person_transported_per_day, String vertical_shaft_depth, float inclination_length, float inclination_angle, int number_of_ropes) {
        this.shaft_number = shaft_number;
        this.shaft_name = shaft_name;
        this.mine_number = mine_number;
        this.mine_name = mine_name;
        this.region_name = region_name;
        this.new_shaft = new_shaft;
        this.shaft_status = shaft_status;
        this.shaft_shape = shaft_shape;
        this.shaft_dimensions = shaft_dimensions;
        this.ventilation_flow = ventilation_flow;
        this.shaft_condition = shaft_condition;
        this.water_condition = water_condition;
        this.avg_person_transported_per_day = avg_person_transported_per_day;
        this.vertical_shaft_depth = vertical_shaft_depth;
        this.inclination_length = inclination_length;
        this.inclination_angle = inclination_angle;
        this.number_of_ropes = number_of_ropes;
    }

 
 
 
 
 
    public int getShaft_number() {
        return shaft_number;
    }

    public void setShaft_number(int shaft_number) {
        this.shaft_number = shaft_number;
    }

    public String getShaft_name() {
        return shaft_name;
    }

    public void setShaft_name(String shaft_name) {
        this.shaft_name = shaft_name;
    }

    public int getMine_number() {
        return mine_number;
    }

    public void setMine_number(int mine_number) {
        this.mine_number = mine_number;
    }

    public String getMine_name() {
        return mine_name;
    }

    public void setMine_name(String mine_name) {
        this.mine_name = mine_name;
    }

    public String getRegion_name() {
        return region_name;
    }

    public void setRegion_name(String region_name) {
        this.region_name = region_name;
    }

    public String getNew_shaft() {
        return new_shaft;
    }

    public void setNew_shaft(String new_shaft) {
        this.new_shaft = new_shaft;
    }

    public String getShaft_status() {
        return shaft_status;
    }

    public void setShaft_status(String shaft_status) {
        this.shaft_status = shaft_status;
    }

    public String getShaft_shape() {
        return shaft_shape;
    }

    public void setShaft_shape(String shaft_shape) {
        this.shaft_shape = shaft_shape;
    }

    public String getShaft_dimensions() {
        return shaft_dimensions;
    }

    public void setShaft_dimensions(String shaft_dimensions) {
        this.shaft_dimensions = shaft_dimensions;
    }

    public String getVentilation_flow() {
        return ventilation_flow;
    }

    public void setVentilation_flow(String ventilation_flow) {
        this.ventilation_flow = ventilation_flow;
    }

    public String getShaft_condition() {
        return shaft_condition;
    }

    public void setShaft_condition(String shaft_condition) {
        this.shaft_condition = shaft_condition;
    }

    public String getWater_condition() {
        return water_condition;
    }

    public void setWater_condition(String water_condition) {
        this.water_condition = water_condition;
    }

    public float getAvg_person_transported_per_day() {
        return avg_person_transported_per_day;
    }

    public void setAvg_person_transported_per_day(float avg_person_transported_per_day) {
        this.avg_person_transported_per_day = avg_person_transported_per_day;
    }

    public String getVertical_shaft_depth() {
        return vertical_shaft_depth;
    }

    public void setVertical_shaft_depth(String vertical_shaft_depth) {
        this.vertical_shaft_depth = vertical_shaft_depth;
    }

    public float getInclination_length() {
        return inclination_length;
    }

    public void setInclination_length(float inclination_length) {
        this.inclination_length = inclination_length;
    }

    public float getInclination_angle() {
        return inclination_angle;
    }

    public void setInclination_angle(float inclination_angle) {
        this.inclination_angle = inclination_angle;
    }

    public int getNumber_of_ropes() {
        return number_of_ropes;
    }

    public void setNumber_of_ropes(int number_of_ropes) {
        this.number_of_ropes = number_of_ropes;
    }

    
 
 
}
