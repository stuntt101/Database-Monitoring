/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Com.mining.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author ERavhengani
 */
public class DButils {
    
    
        public static PreparedStatement getPreparedStatement(String sql) throws ClassNotFoundException, SQLException{
        PreparedStatement ps = null;
        Class.forName("com.mysql.jdbc.Driver");
       String URL = "jdbc:mysql://localhost:3306/mine_management";
       String USERNAME = "root"; 
       String PASSWORD = "13579";
        
         
        Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        ps= con.prepareStatement(sql);
        
        
        return ps;
            }
         
        //public static void main(String [] args) throws ClassNotFoundException, SQLException {
            //getPreparedStatement("SELECT * FROM shaft");
    
    
    
//}
} 