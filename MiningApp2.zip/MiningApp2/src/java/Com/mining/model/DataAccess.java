/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Com.mining.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ERavhengani
 */
public class DataAccess {
    
    public void addNew(Viewing n ){
    
        try {
            PreparedStatement ps = DButils.getPreparedStatement("INSERT INTO shaft VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                ps.setInt(1, n.getShaft_number());
                ps.setString(2,n.getShaft_name());
                ps.setInt(3,n.getMine_number());
                ps.setString(4, n.getMine_name());
                ps.setString(5, n.getRegion_name());
                ps.setString(6, n.getNew_shaft());
                ps.setString(7, n.getShaft_status());
                ps.setString(8, n.getShaft_shape());
                ps.setString(9, n.getShaft_dimensions());
                ps.setString(10, n.getVentilation_flow());
                ps.setString(11, n.getShaft_condition());
                ps.setString(12, n.getWater_condition());
                ps.setFloat(13, n.getAvg_person_transported_per_day());
                ps.setString(14, n.getVertical_shaft_depth()); 
                ps.setFloat(15, n.getInclination_length());
                ps.setFloat(16, n.getInclination_angle());
                ps.setInt(17, n.getNumber_of_ropes());
                
                 
                
                
        
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DataAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        

    
    }
            public static List<Viewing> getAll(){
          List <Viewing> ls = new LinkedList<>();
          
        try {
            ResultSet rs = DButils.getPreparedStatement("SELECT * FROM shaft").executeQuery();
            
            while(rs.next()){
                Viewing n = new Viewing(rs.getInt(1),rs.getString(2), rs.getInt(3),rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getFloat(13), rs.getString(14), rs.getFloat(15), rs.getFloat(16), rs.getInt(17));
                
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DataAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
             
          
          return ls;
        }
    
}
