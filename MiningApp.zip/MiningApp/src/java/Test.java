/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LQwabe
 */
import com.mining.model.Inspector;
import com.mining.model.Region;
import com.mining.service.*;
public class Test {
    public static void main(String[] args){
    Region region=new Region("South Africa");
    String region2= region.getRegionName();
    
    Inspector ins =new Inspector("Lungelo", "121212", "Lungelo", "test","test",region );
    InspectorService registerService = new InspectorService();
    boolean results = registerService.createInspector(ins);
    if(results) {
	System.out.println("Data saved");
    }
    else{
	System.out.println("Data not saved");
    }
    
    }
}
