/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 *
 * @author LQwabe
 */
@Entity
@Table(name = "manager")

public class Manager implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;
    @Basic(optional = false)
    @Column(name = "firstname")
    private String firstname;
    @Basic(optional = false)
    @Column(name = "lastname")
    private String lastname;
    @Column(name = "email_address")
    private String emailAddress;
    @Basic(optional = false)
    @Column(name = "mine_name")
    private String mineName;
    @JoinColumn(name = "region_name", referencedColumnName = "region_name")
    @ManyToOne(optional = false)
    private Region regionName;
    @JoinColumn(name = "mine_number", referencedColumnName = "mine_number")
    @ManyToOne(optional = false)
    private Mine mineNumber;

    public Manager() {
    }


    public Manager(String username, String password, String firstname, 
	    String lastname,String emailAddress, String mineName,Region regionName, Mine mineNumber) {
	this.username = username;
	this.password = password;
	this.firstname = firstname;
	this.lastname = lastname;
	this.emailAddress=emailAddress;
	this.mineName = mineName;
	this.regionName=regionName;
	this.mineNumber=mineNumber;
    }
    
    public Manager(String username, String password, String firstname, String lastname, String mineName) {
	this.username = username;
	this.password = password;
	this.firstname = firstname;
	this.lastname = lastname;
	this.mineName = mineName;
    }

    public String getUsername() {
	return username;
    }

    public void setUsername(String username) {
	this.username = username;
    }

    public String getPassword() {
	return password;
    }

    public void setPassword(String password) {
	this.password = password;
    }

    public String getFirstname() {
	return firstname;
    }

    public void setFirstname(String firstname) {
	this.firstname = firstname;
    }

    public String getLastname() {
	return lastname;
    }

    public void setLastname(String lastname) {
	this.lastname = lastname;
    }

    public String getEmailAddress() {
	return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
    }

    public String getMineName() {
	return mineName;
    }

    public void setMineName(String mineName) {
	this.mineName = mineName;
    }

    public Region getRegionName() {
	return regionName;
    }

    public void setRegionName(Region regionName) {
	this.regionName = regionName;
    }

    public Mine getMineNumber() {
	return mineNumber;
    }

    public void setMineNumber(Mine mineNumber) {
	this.mineNumber = mineNumber;
    }
    
}
