/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author LQwabe
 */
@Entity
@Table(name = "region")

public class Region implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "region_name")
    private String regionName;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private Collection<Manager> managerCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private Collection<Inspector> inspectorCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regionName")
    private Collection<Mine> mineCollection;

    public Region() {
    }

    public Region(String regionName) {
	this.regionName = regionName;
    }

    public String getRegionName() {
	return regionName;
    }

    public void setRegionName(String regionName) {
	this.regionName = regionName;
    }

    @XmlTransient
    public Collection<Manager> getManagerCollection() {
	return managerCollection;
    }

    public void setManagerCollection(Collection<Manager> managerCollection) {
	this.managerCollection = managerCollection;
    }

    @XmlTransient
    public Collection<Inspector> getInspectorCollection() {
	return inspectorCollection;
    }

    public void setInspectorCollection(Collection<Inspector> inspectorCollection) {
	this.inspectorCollection = inspectorCollection;
    }

    @XmlTransient
    public Collection<Mine> getMineCollection() {
	return mineCollection;
    }

    public void setMineCollection(Collection<Mine> mineCollection) {
	this.mineCollection = mineCollection;
    }

    @Override
    public int hashCode() {
	int hash = 0;
	hash += (regionName != null ? regionName.hashCode() : 0);
	return hash;
    }

    @Override
    public boolean equals(Object object) {
	// TODO: Warning - this method won't work in the case the id fields are not set
	if (!(object instanceof Region)) {
	    return false;
	}
	Region other = (Region) object;
	if ((this.regionName == null && other.regionName != null) || (this.regionName != null && !this.regionName.equals(other.regionName))) {
	    return false;
	}
	return true;
    }

    @Override
    public String toString() {
	return "entity.Region[ regionName=" + regionName + " ]";
    }
    
}
