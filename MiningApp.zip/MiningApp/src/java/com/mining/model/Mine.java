/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author LQwabe
 */
@Entity
@Table(name = "mine")

public class Mine implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "mine_number")
    private Integer mineNumber;
    @Basic(optional = false)
    @Column(name = "mine_name")
    private String mineName;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mineNumber")
    private Collection<Manager> managerCollection;
    @JoinColumn(name = "region_name", referencedColumnName = "region_name")
    @ManyToOne(optional = false)
    private Region regionName;

    public Mine() {
    }


    public Mine(Integer mineNumber, String mineName, Region regionName) {
	this.mineNumber = mineNumber;
	this.mineName = mineName;
	this.regionName= regionName;
    }

    public Integer getMineNumber() {
	return mineNumber;
    }

    public void setMineNumber(Integer mineNumber) {
	this.mineNumber = mineNumber;
    }

    public String getMineName() {
	return mineName;
    }

    public void setMineName(String mineName) {
	this.mineName = mineName;
    }

    @XmlTransient
    public Collection<Manager> getManagerCollection() {
	return managerCollection;
    }

    public void setManagerCollection(Collection<Manager> managerCollection) {
	this.managerCollection = managerCollection;
    }

    public Region getRegionName() {
	return regionName;
    }

    public void setRegionName(Region regionName) {
	this.regionName = regionName;
    }

    
}
