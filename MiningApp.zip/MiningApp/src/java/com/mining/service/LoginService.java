package com.mining.service;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mining.hibernate.util.HibernateUtil;
import com.mining.model.Admin;

public class LoginService {

    public boolean authenticateUser(String username, String password) {
        Admin admin = getAdminByUsername(username);          
        if(admin!=null && admin.getUsername().equals(username) && admin.getPassword().equals(password)){
            return true;
        }else{ 
            return false;
        }
    }

    public Admin getAdminByUsername(String username) {
        Session session = HibernateUtil.openSession();
        Transaction tx = null;
        Admin admin = null;
        try {
            tx = session.getTransaction();
            tx.begin();
            Query query = session.createQuery("from Admin where username='"+username+"'");
            admin = (Admin)query.uniqueResult();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return admin;
    }
    
    public List<Admin> getListOfAdmins(){
        List<Admin> list = new ArrayList<Admin>();
        Session session = HibernateUtil.openSession();
        Transaction tx = null;        
        try {
            tx = session.getTransaction();
            tx.begin();
            list = session.createQuery("from Admin").list();                        
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return list;
    }
}
