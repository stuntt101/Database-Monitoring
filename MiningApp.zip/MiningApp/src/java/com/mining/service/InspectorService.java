/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mining.service;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mining.hibernate.util.HibernateUtil;
import com.mining.model.Inspector;

/**
 *
 * @author LQwabe
 */
public class InspectorService {
    
    public boolean createInspector(Inspector inspector){
	 Session session = HibernateUtil.openSession();
	 if(isInspectorExists(inspector)) 
	    return false;	
	
	 Transaction tx = null;	
	 try {
		 tx = session.getTransaction();
		 tx.begin();
		 session.saveOrUpdate(inspector);		
		 tx.commit();
	 } catch (Exception e) {
		 if (tx != null) {
			 tx.rollback();
		 }
		 e.printStackTrace();
	 } finally {
		 session.close();
	 }	
	 return true;
}
    public boolean isInspectorExists(Inspector inspector){
	 Session session = HibernateUtil.openSession();
	 boolean result = false;
	 Transaction tx = null;
	 try{
		 tx = session.getTransaction();
		 tx.begin();
		 Query query = session.createQuery("from Inspector where username='"+inspector.getUsername()+"'");
		 Inspector ins = (Inspector)query.uniqueResult();
		 tx.commit();
		 if(ins!=null) result = true;
	 }catch(Exception ex){
		 if(tx!=null){
			 tx.rollback();
		 }
	 }finally{
		 session.close();
	 }
     return result;
    }
}
